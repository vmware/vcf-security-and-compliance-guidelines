VMware Validated Design 5.1.1 Compliance Kit for NIST 800-53 consists of multiple files and must be used as a complete package:
1. Introducing Security and Compliance
2. Product Applicability Guide
3. Configuration Guide
4. Audit Guide
5. Audit Guide Appendices

You can send feedback to compliance-solutions@vmware.com

VMware, Inc.
3401 Hillview Ave.
Palo Alto, CA 94304
www.vmware.com
Copyright © 2019-2020 VMware, Inc. All rights reserved.