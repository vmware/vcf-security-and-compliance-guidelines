Function Harden-ESXiHost
{
	<#

	.SYNOPSIS
	Hardens ESXI Hosts in VCF Environment.

	.DESCRIPTION
	This Cmdlet is used to harden ESXI hosts based on the regulatory standard and domain of interest.
	The regulatory standards supported are  NIST, PCI and DISA.
	More support will be added in the future.
	
	.EXAMPLE
	Harden-ESXiHost -RegulatoryStandard NIST -DomainName <Domain Name> -ReportPath <Path where reports are saved and logs to be saved>
	Harden-ESXiHost -RegulatoryStandard PCI -DomainName <Domain Name> -ReportPath <Path where reports are saved and logs to be saved>
	Harden-ESXiHost -RegulatoryStandard DISA -DomainName <Domain Name> -ReportPath <Path where reports are saved and logs to be saved>

	.NOTES
	Connect to VCF Server using Connect-VCFServer before running Harden-ESXiHost Cmdlet.
	Run audit before hardening vCenter Servers.
	
	#>
	
	Param(
		[ValidateSet("DISA","PCI","NIST",IgnoreCase=$true)]
		[Parameter(mandatory=$true)]
        [String]$RegulatoryStandard,
		[Parameter(mandatory=$true)]
        [String]$DomainName,
		[Parameter(mandatory=$true)]
        [String]$ReportPath
	)
	
	$domainName = $DomainName.trim()
	$esxiHardeningDetails = @{}
	if($vcfSession.Session -eq 0){
		Throw "You are not currently connected to SDDC Manager. Please connect using Connect-VCFServer cmdlet."
	}
	
	$fileNames = Get-ChildItem -Path $ReportPath
	if($fileNames.Name -Match $RegulatoryStandard+"_"+$domainName+"_"+"ESXi"){

		$configFileName = $RegulatoryStandard.toLower()+"Config.json"
		$filePath = Join-Path -Path $PSScriptRoot -ChildPath $configFileName
		$configData = (Get-Content -Path $filePath -Raw )  | ConvertFrom-Json
		
		$inputFileName = "inputSpec.json"
		$inputFilePath = Join-Path -Path $PSScriptRoot -ChildPath $inputFileName
		$inputSpecData = (Get-Content -Path $inputFilePath -Raw )  | ConvertFrom-Json
		
		$vcfCredentials = Select-Domain $domainName
		
		$totalNoOfESXiConfigurations = 0
		if($domainName -eq "All"){
				Write-Progress " Remediating ESXi hosts of $domainName Workload Domains:"
		}
		else{
			Write-Progress " Remediating ESXi hosts of $domainName Workload Domain"
		}					   
		$logName = $RegulatoryStandard.toUpper() + "_hardenESXi"
		$product = "ESXi"
		
		$toHarden = Read-Host -Prompt "This Operation will make Configurational changes on your ESXi Hosts - Do you want to proceed - Yes/No?"
		if($toHarden -like "y*" ){
			Foreach($vc in $vcfCredentials["vCenterList"].fqdn){
				Connect-viserver -Server $vc -username $vcfCredentials["vcusername"] -password $vcfCredentials["vcpassword"] >> $ReportPath\\$logName.log
				$esxiHosts = Get-VMHost
				
				Foreach($esxiHost in $esxiHosts){
					Write-Progress "Remediating $esxiHost..."
					
					$noOfEsxiConfigurationsRemediated = 0
			
					#New addition, condition to be updated after audit for the same config is done. Added the config in all the 3 config json files
					
					$label = "VI-ESXi-AUD-00022"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if ($resultESXi.Value -ne $configData.$product.$label.DesiredValue)
					{
						$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
						$noOfEsxiConfigurationsRemediated++
					}
					
					#New addtion, need to handle the use case where customer may provide list of IP addresses
					$label = "VI-ESXi-AUD-00028"
					$resultESXi = $esxiHost | Get-VMHostFirewallException | Where-Object {$_.Name -eq 'SSH Server' -and $_.Enabled -eq $true} | Select-Object Name,Enabled,@{N="AllIPEnabled";E={$_.ExtensionData.AllowedHosts.AllIP}}
					if($resultESXi.AllIPEnabled -ne $false){
						$noOfEsxiConfigurationsRemediated++
						$esxcli = Get-EsxCli -v2 -VMHost $esxiHost.Name
						#This disables the allow all rule for the target service. We are targeting the sshServer service in this example.
						$arguments = $esxcli.network.firewall.ruleset.set.CreateArgs() #>> $ReportPath\$logName.log
						$arguments.rulesetid = "sshServer"
						$arguments.allowedall = $ConfigData.$product.$label.DesiredValue
						$esxcli.network.firewall.ruleset.set.Invoke($arguments) >> $ReportPath\$logName.log
						
						#List the Ip addresses set on the service
						$arguments = $esxcli.network.firewall.ruleset.allowedip.add.CreateArgs()
						$arguments.rulesetid = "sshServer"
						$ipAddresses = $esxcli.network.firewall.ruleset.allowedip.list.Invoke($arguments)
						if($ipAddresses.AllowedIPAddresses)
						{
							#Remove the Ip addresses set on the service
							foreach($address in $ipAddresses.AllowedIPAddresses){
								$arguments = $esxcli.network.firewall.ruleset.allowedip.add.CreateArgs()
								$arguments.rulesetid = "sshServer"
								$arguments.ipaddress = $address
								$esxcli.network.firewall.ruleset.allowedip.remove.Invoke($arguments) >> $ReportPath\$logName.log
							}
						}
						
						#Next add the allowed Site-Specific IPs for the service.
						$ipAddresses = $inputSpecData.$product.$label.AllowedIPaddresses
						$addresses = $ipAddresses.split(",")
						foreach($address in $addresses){
							$arguments = $esxcli.network.firewall.ruleset.allowedip.add.CreateArgs()
							$arguments.rulesetid = "sshServer"
							$ipAddress = $address
							$arguments.ipaddress = $ipAddress
							$esxcli.network.firewall.ruleset.allowedip.add.Invoke($arguments) >> $ReportPath\$logName.log
						}
					}
					
					$label = "VI-ESXi-AUD-00030"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if ($resultESXi.Value -ne $configData.$product.$label.DesiredValue)
					{
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-00031"
					$resultESXi = Get-VMHost $esxiHost | Select-Object Name,@{N="Lockdown";E={$_.Extensiondata.Config.LockdownMode}}
					if($resultESXi.Lockdown -eq "lockdownDisabled"){
						(get-vmhost $esxiHost | get-view).EnterLockdownMode()
						$noOfEsxiConfigurationsRemediated++
					}
				
					$label = "VI-ESXi-AUD-00034"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if ($resultESXi.Value -ne $configData.$product.$label.DesiredValue)
					{
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-00038"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if($resultESXi.Value -ne $configData.$product.$label.DesiredValue)
					{
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-00043"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if ($resultESXi.Value -ne $configData.$product.$label.DesiredValue)
					{
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
				
					$label = "VI-ESXi-AUD-00105"
					$resultESXi = $esxiHost | Get-VMHostFirewallDefaultPolicy
					if($resultESXi.IncomingEnabled -ne $False)
					{
					$esxiHost | Get-VMHostFirewallDefaultPolicy | Set-VMHostFirewallDefaultPolicy -AllowIncoming $false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-00106"
					$resultESXi = $esxiHost | Get-VMHostFirewallDefaultPolicy
					if($resultESXi.OutgoingEnabled -ne $False)
					{
					$esxiHost | Get-VMHostFirewallDefaultPolicy | Set-VMHostFirewallDefaultPolicy -AllowOutgoing $false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-00109"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if ($resultESXi.Value -ne $configData.$product.$label.DesiredValue)
					{
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-00112"
					$resultESXi = $esxiHost | Get-VMHostService | Where-Object {$_.Label -eq "ESXi Shell"}
					if ($resultESXi.Running -ne $False -OR $resultESXi.Policy -ne "Off")
					{
					$esxiHost | Get-VMHostService | Where-Object {$_.Label -eq "ESXi Shell"} | Set-VMHostService -Policy Off -Confirm:$false  >> $ReportPath\$logName.log
					$esxiHost | Get-VMHostService | Where-Object {$_.Label -eq "ESXi Shell"} | Stop-VMHostService -Confirm:$false  >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					#New config (non-default), to review and update as per inputSpecjson
					<#$label = "VI-ESXi-AUD-00114"
					$resultESXi = $esxiHost | Get-VMHostAuthentication
					if ($resultESXi.DomainMembershipStatus -ne $inputSpecData.$product.$label.DesiredValue)
					{
					$esxiHost | Get-VMHostAuthentication | Set-VMHostAuthentication -JoinDomain -Domain $inputSpecData.$product.$label.DomainName -User $inputSpecData.$product.$label.Username -Password $inputSpecData.$product.$label.Password -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}#>
							
					$label = "VI-ESXi-AUD-00122"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if($resultESXi.value -eq ""){
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $inputSpecData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-00123"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if($resultESXi.value -eq ""){
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $inputSpecData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-00136"
					$esxcli = Get-EsxCli -v2 -VMHost $esxiHost.Name
					$resultESXi = $esxcli.system.syslog.config.get.Invoke() | Select-Object LocalLogOutput,LocalLogOutputIsPersistent
					if($resultESXi.LocalLogOutputIsPersistent -ne $ConfigData.$product.$label.DesiredValue){
						$esxiHost | Get-AdvancedSetting -Name Syslog.global.logDir | Set-AdvancedSetting -Value $inputSpecData.$product.$label.PersistentLocation -Confirm:$false >> $ReportPath\$logName.log
						$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-00137"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if ($resultESXi.Value -eq "ESX Admins"){
						$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $inputSpecData.$product.$label.ADGroup -Confirm:$false >> $ReportPath\$logName.log
						$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-00138"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if ($resultESXi.Value -ne $configData.$product.$label.DesiredValue)
					{
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					#Default config
					<#$label = "VI-ESXi-AUD-00147"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					$NTPServers = $inputSpecData.$product.$label.DesiredValue
					$resultESXi = $esxiHost | Add-VMHostNTPServer $NTPServers
					if ($resultESXi.Value -ne $inputSpecData.$product.$label.DesiredValue)
					{
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $inputSpecData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}#>
					
					$label = "VI-ESXi-AUD-00148"
					$resultESXi = $esxiHost | Get-VMHostService | Where-Object {$_.Label -eq "NTP Daemon"}
					if ($resultESXi.Policy -ne $configData.$product.$label.DesiredValue)
					{
					$esxiHost | Get-VMHostService | Where-Object {$_.Label -eq "NTP Daemon"} | Set-VMHostService -Policy $configData.$product.$label.DesiredValue >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-00149"
					$resultESXi = $esxiHost | Get-VMHostService | Where-Object {$_.Label -eq "NTP Daemon"}
					if ($resultESXi.Running -ne $configData.$product.$label.DesiredValue)
					{
					$esxiHost | Get-VMHost | Get-VMHostService | Where-Object {$_.Label -eq "NTP Daemon"} | Start-VMHostService >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-00157"
					$esxcli = Get-EsxCli -v2 -VMHost $esxiHost.Name
					$resultESXi = $esxcli.software.acceptance.get.Invoke()
					
					if ($resultESXi -eq "CommunitySupported")
					{
						
						$arguments = $esxcli.software.acceptance.set.CreateArgs()
						$arguments.level = "PartnerSupported"
						$esxcli.software.acceptance.set.Invoke($arguments) >> $ReportPath\$logName.log
						$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-00163"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if ($resultESXi.Value -ne $configData.$product.$label.DesiredValue)
					{
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-00164"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if (!$resultESXi.Value)
					{
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $inputSpecData.$product.$label.SyslogServers -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-00165"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if ($resultESXi.Value -ne $configData.$product.$label.DesiredValue)
					{
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-00166"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if ($resultESXi.Value -ne $false)
					{
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-00168"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if ($resultESXi.Value -ne $configData.$product.$label.DesiredValue)
					{
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName  | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-00169"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if ($resultESXi.Value -ne $configData.$product.$label.DesiredValue)
					{
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName  | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}

					$label = "VI-ESXi-AUD-00179"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if ($resultESXi.Value -ne $configData.$product.$label.DesiredValue)
					{
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}

					$label = "VI-ESXi-AUD-00564"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if ($resultESXi.Value -ne $configData.$product.$label.DesiredValue)
					{
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}			
					
					$label = "VI-ESXi-AUD-01100"
					$esxcli = Get-EsxCli -v2 -VMHost $esxiHost.Name
					$resultESXi = $esxcli.system.security.fips140.ssh.get.invoke()
					if($resultESXi.Enabled -ne "true")
					{
					$arguments = $esxcli.system.security.fips140.ssh.set.CreateArgs()
					$arguments.enable = $true
					$esxcli.system.security.fips140.ssh.set.Invoke($arguments) >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-01107"
					$rebootFlag = 0
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if ($resultESXi.Value -notmatch "tlsv1" -OR $resultESXi.Value -notmatch "tlsv1.1" -OR $resultESXi.Value -notmatch "sslv3")
					{
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					$rebootFlag = 1
					}
					
					$label = "VI-ESXi-AUD-01109"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if ($resultESXi.Value -ne $configData.$product.$label.DesiredValue)
					{
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-01110"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if ($resultESXi.Value -ne $configData.$product.$label.DesiredValue)
					{
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					$label = "VI-ESXi-AUD-01112"
					$resultESXi = $esxiHost | Get-VMHostService | Where-Object {$_.Label -eq "slpd"}
					if ($resultESXi.Running -ne $False -OR $resultESXi.Policy -ne "Off")
					{
					$esxiHost | Get-VMHostService | Where-Object {$_.Label -eq "slpd"} | Set-VMHostService -Policy Off -Confirm:$false  >> $ReportPath\$logName.log
					$esxiHost | Get-VMHostService | Where-Object {$_.Label -eq "slpd"} | Stop-VMHostService -Confirm:$false  >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					#New addtion (default config), to review
					$label = "VI-ESXi-AUD-01116"
					$resultESXi = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if ($resultESXi.Value -ne $configData.$product.$label.DesiredValue)
					{
					$esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					#New addtion (default config), to review
					$label = "VI-ESXi-AUD-01117"
					$esxcli = Get-EsxCli -v2 -VMHost $esxiHost.Name
					$resultESXi = $esxcli.system.security.fips140.rhttpproxy.get.invoke()
					if ($resultESXi.Enabled -ne "true")
					{
					$arguments = $esxcli.system.security.fips140.rhttpproxy.set.CreateArgs()
					$arguments.enable = $true
					$esxcli.system.security.fips140.rhttpproxy.set.Invoke($arguments) >> $ReportPath\$logName.log
					$noOfEsxiConfigurationsRemediated++
					}
					
					Write-Verbose "$noOfEsxiConfigurationsRemediated configurations on $esxiHost is remediated"
					$totalNoOfESXiConfigurations += $noOfEsxiConfigurationsRemediated
					
				}
				

				if ($rebootFlag -eq 1){
					Write-Verbose "Host reboot on $esxiHost is required for changes to take effect"
				}		
				disconnect-viserver -Server $vc -Confirm:$false
			}
			
			if($totalNoOfESXiConfigurations -gt 0){
				$remediationMessage = "Please re-run Audit-ESXHost to check the status after Hardening"
			}
			else{
				$remediationMessage = "None of the Configurations got remediated"
			}
		}
		elseif($toHarden -like "n*"){
			$remediationMessage = "You must harden your ESXi Hosts to be compliant with $RegulatoryStandard"
		}
		else{
			throw "Invalid Input. Please try again."
		}
		$esxiHardeningDetails["TotalNoOfEsxiConfigurationsRemediated"] = $totalNoOfESXiConfigurations
		$esxiHardeningDetails["RemediationMessage"] = $remediationMessage
		return $esxiHardeningDetails
	}
	else{
		Throw "Please run Audit-ESXiHost with RegulatorStandard : $RegulatoryStandard and DomainName : $domainName before hardening"
	}
	
	
}