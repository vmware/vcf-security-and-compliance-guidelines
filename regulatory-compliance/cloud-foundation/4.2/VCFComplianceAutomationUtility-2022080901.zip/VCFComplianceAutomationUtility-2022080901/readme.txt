## Introduction
Compliance Automation Utility is a PowerShell module that consists of functions/cmdlets to audit and harden components of the VMware Cloud Foundation (VCF) core stack (vSphere, NSX-T, SDDC Manager). The utility automates the security configurations that are part of the VCF Compliance Kit.

[VMware Cloud Foundation Compliance Kit](https://core.vmware.com/compliance)
. Configuration list covered as part of utility can be found in the Compliance Utility bundle(ComplianceAutomationUtility.zip file) with the file name - Configurations_Covered_By_Utility.pdf. 

### List of Cmdlets
1. Audit-ESXiHost
2. Audit-VcenterServer
3. Auidt-VirtualMachine
4. Auidt-NsxtManager
5. Audit-SDDCManager
6. Audit-All
7. Harden-ESXiHost
8. Harden-VcenterServer
9. Harden-VirtualMachine
10. Harden-NsxtManager
11. Harden-SDDCManager
12. Connect-VCFServer

### Supported VCF Versions
* Minimum supported version : 4.2.0
* Maximum supported version : 4.3.1

### Supported Regulatory standards
1. NIST 800-53
2. PCI DSS 3.2.1
3. DISA

### Supported Report format types
1. JSON
2. Excel

## Requirements

* Windows PowerShell 5.0 Or Windows PowerShell Core 7.2.4 and above
* Before you use this module, you must install a few modules from the PowerShell Gallery. Run the following commands to install the modules:
	* PowerCLI (Version 12.0 and above): `Install-Module -Name VMware.PowerCLI`
	* PowerVCF (Version 2.1.7 and above): `Install-Module -Name PowerVCF`
	* ImportExcel (Version 7.5.0 and above): `Install-Module -Name ImportExcel`
	* VMware.vSphere.SsoAdmin(Version 1.3.8 and above): `Install-Module -Name VMware.vSphere.SsoAdmin`

## Installing the Module

* Downlod all the module files from the following git location: [Compliance Automation Utility](https://gitlab.eng.vmware.com/mmalavallii/complianceautomationutility).
* Open Powershell as Administrator.
* Set the execution policy to allow execution of module files.
* Change the directory to the path where the module files are downloaded.
* Run the following command to import the module manifest:

  `Import-Module -Name .\ComplianceUtility.psd1`
* Run the following command to list the cmdlets available as part of the module:

  `Get-Command -Module ComplianceUtility`

## Getting Started
 
* Before you run any cmdlets, you must fill the inputSpec.json file with the site-specific values. Refer to the sampleInputSpec.txt  file for guidance on each input.
* Connect to SDDC Manager using `Connect-VCFServer` cmdlet by providing credentials of SDDC Manager.
* Run any of the cmdlets that are part of the module by providing Regulatory standard and domain name as mandatory   parameters.
	Examples:

	`Audit-ESXiHost -RegulatoryStandard PCI -domainName mgmtDomain -reportPath F:\Reports`
	
	`Audit-ESXiHost -RegulatoryStandard DISA -domainName wldDomain -reportPath F:\Reports`

	`Audit-ESXiHost -RegulatoryStandard NIST -domainName mgmtDomain -reportPath F:\Reports`

#### Notes / Limitations

* The utility does not automate all the configurations available in the VCF Compliance kit.
* The utility is not tested beyond lab scenarios. It is recommended you dont use it for any production environment without testing extensively!
* The utility is not tested on Non-Windows enviornment.
* Run Audit cmdlets before running Harden cmdlets.
* Report path must be same while running audit and harden cmdlets.
* You must run audit cmdlet after hardening to view the compliance status. There are no reports generated via the harden cmdlet.
* The utility is tested on an environment which has a management domain and workload domain. Not tested against the environment which has multiple VI workload domains.

## Known Issues

* Reconnecting to the SDDC Manager using Connect-VCFServer is required if the session is expired. Errors might appear if any cmdlets are executed when the session is expired.
* Running `Connect-VCFServer` cmdlet throws the following error if you run from Windows 2012 client and it uses CBC ciphers : "The request was aborted: Could not create SSL/TLS secure channel." Workaround: Follow the steps as mentioned in the KB article: https://kb.vmware.com/s/article/86317?lang=en_US and run the cmdlet again.


## Maintainers
1.	Madhusudan M I
2.	Diti Sharadbhai Dave

