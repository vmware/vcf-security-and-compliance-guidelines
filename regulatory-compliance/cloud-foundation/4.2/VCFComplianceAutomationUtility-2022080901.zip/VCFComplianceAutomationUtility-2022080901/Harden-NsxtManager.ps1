Function Harden-NsxtManager
{
	<#

	.SYNOPSIS
	Hardens NSXT Manager in VCF Environment.

	.DESCRIPTION
	This Cmdlet is used to harden NSXT Managers based on the regulatory standard and domain of interest.
	The regulatory standards supported are  NIST, PCI and DISA.
	More support will be added in the future.
	
	.EXAMPLE
	Harden-NsxtManager -RegulatoryStandard NIST -DomainName <Domain Name> -ReportPath <Path where reports are saved and logs to be saved>
	Harden-NsxtManager -RegulatoryStandard PCI -DomainName <Domain Name> -ReportPath <Path where reports are saved and logs to be saved>
	Harden-NsxtManager -RegulatoryStandard DISA -DomainName <Domain Name> -ReportPath <Path where reports are saved and logs to be saved>

	.NOTES
	Connect to VCF Server using Connect-VCFServer before running Harden-NsxtManager Cmdlet.
	Run audit before hardening NSXT managers.
	
	#>
	
	Param(
		[ValidateSet("DISA","PCI","NIST",IgnoreCase=$true)]
		[Parameter(mandatory=$true)]
        [String]$RegulatoryStandard,
		[Parameter(mandatory=$true)]
        [String]$DomainName,
		[Parameter(mandatory=$true)]
        [String]$ReportPath
	)
	
	$domainName = $DomainName.trim()
	$nsxtHardeningDetails = @{}
	if($vcfSession.Session -eq 0){
		Throw "You are not currently connected to SDDC Manager. Please connect using Connect-VCFServer cmdlet."
	}
	
	$fileNames = Get-ChildItem -Path $ReportPath
	if($fileNames.Name -Match $RegulatoryStandard+"_"+$domainName+"_"+"NSXT"){
		
		$configFileName = $RegulatoryStandard.toLower()+"Config.json"
		$filePath = Join-Path -Path $PSScriptRoot -ChildPath $configFileName
		$configData = (Get-Content -Path $filePath -Raw )  | ConvertFrom-Json
		
		<#$inputFileName = "inputSpec.json"
		$inputFilePath = Join-Path -Path $PSScriptRoot -ChildPath $inputFileName
		$inputSpecData = (Get-Content -Path $inputFilePath -Raw )  | ConvertFrom-Json
		#>
		$vcfCredentials = Select-Domain $domainName
		
		if($domainName -eq "All"){
				Write-Progress " Remediating NSX-T Managers of $domainName the Workload Domains:"
		}
		else{
			Write-Progress " Remediating NSX-T Managers of $domainName Workload Domain: $domainName"
		}
		
		$product = "NSX-T"
		
		$totalNoOfNsxtConfigurations = 0
		#$logName = $RegulatoryStandard.toUpper() + "_hardenNsxt"
		
		$toHarden = Read-Host -Prompt "This Operation will make Configurational changes on your NSX-T managers - Do you want to proceed - Yes/No?"
		if($toHarden -like "y*" ){
			Foreach($nsxt in $vcfCredentials["nsxtNodesList"].fqdn)
			{
				Write-Progress "Remediating $nsxt..."
				$noOfNSXTConfigurations = 0
				
				if($domainName -eq "All"){
					$nsxtCredentials = Get-VCFCredential | Where-Object {$_.credentialType -eq "API" -and $_.resource.resourceType -eq "NSXT_MANAGER" -and $_.resource.resourceId -eq $vcfCredentials["nsxtClusterNodesList"][$nsxt]} | Select-Object username, password
					$user = $nsxtCredentials.userName
					$pass = $nsxtCredentials.password
			
				}	
				else{
					$user = $vcfCredentials["nsxtUsername"].username
					$pass = $vcfCredentials["nsxtPassword"].password
				}
		
				$pair = "$($user):$($pass)"
				$encodedCreds = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($pair))
				$basicAuthValue = "Basic $encodedCreds"

				$headers = @{
					Authorization = $basicAuthValue
				}
			
				$label = "VI-NET-AUD-01416"
			
				$uri = "https://$nsxt/api/v1/cluster/api-service"
				$apiServiceConfig = GetNsxtAPIMethod $uri $headers
				if($apiServiceConfig.session_timeout -ne $configData.$product.$label.DesiredValue)
				{
					$noOfNSXTConfigurations++
					$apiServiceConfig.session_timeout = $configData.$product.$label.DesiredValue
				}
				
				$label = "VI-NET-AUD-01423"
				$desiredValue = $configData.$product.$label.DesiredValue
				$splittedValues = $desiredValue.Split(",")
				$client_api_rate_limit = [int]$splittedValues[0].split(":")[1]
				$client_api_concurrency_limit = [int]$splittedValues[1].split(":")[1]
				$global_api_concurrency_limit = [int]$splittedValues[2].split(":")[1]
				
				if($apiServiceConfig.client_api_concurrency_limit -ne $client_api_concurrency_limit -or $apiServiceConfig.client_api_rate_limit -ne $client_api_rate_limit -or $apiServiceConfig.global_api_concurrency_limit -ne $global_api_concurrency_limit)
				{
					#Write-Verbose $label
					$noOfNSXTConfigurations++
					if($apiServiceConfig.global_api_concurrency_limit -ne $global_api_concurrency_limit)
					{
						$apiServiceConfig.global_api_concurrency_limit = $global_api_concurrency_limit
						
						
					}
					if($apiServiceConfig.client_api_rate_limit -ne $client_api_rate_limit)
					{
						$apiServiceConfig.client_api_rate_limit = $client_api_rate_limit
						
					}
					if($apiServiceConfig.client_api_concurrency_limit -ne $client_api_concurrency_limit)
					{
						$apiServiceConfig.client_api_concurrency_limit = $client_api_concurrency_limit
						
					}
				}#>
				
				$body = $apiServiceConfig | ConvertTo-Json
				$uri = "https://$nsxt/api/v1/cluster/api-service"
				
				PutNsxtAPIMethod $uri $headers $body
				
				$label = "VI-NET-AUD-01499"
				
				$uri = "https://$nsxt/api/v1/node"
				$nodeConfig = GetNsxtAPIMethod $uri $headers
				
				if($nodeConfig.cli_timeout -ne $configData.$product.$label.DesiredValue)
				{
					#Write-Verbose $label
					$noOfNSXTConfigurations++
					$nodeConfig.cli_timeout = $configData.$product.$label.DesiredValue
				}
				
				$body = $nodeConfig | ConvertTo-Json
				$uri = "https://$nsxt/api/v1/node"
				PutNsxtAPIMethod $uri $headers $body
				
				$uri = "https://$nsxt/api/v1/node/aaa/auth-policy"
				$authPolicyConfig = GetNsxtAPIMethod $uri $headers
			
				$label = "VI-NET-AUD-01417"
				if($authPolicyConfig.api_failed_auth_lockout_period -ne $configData.$product.$label.DesiredValue){
						#Write-Verbose $label
					$noOfNSXTConfigurations++
					$authPolicyConfig.api_failed_auth_lockout_period = $configData.$product.$label.DesiredValue
				}
				
				$label = "VI-NET-AUD-01419"
				if($authPolicyConfig.api_failed_auth_reset_period -ne $configData.$product.$label.DesiredValue){
					#Write-Verbose $label
					$noOfNSXTConfigurations++
					$authPolicyConfig.api_failed_auth_reset_period = $configData.$product.$label.DesiredValue
				}
				$label = "VI-NET-AUD-01418"
				if($authPolicyConfig.api_max_auth_failures -ne $configData.$product.$label.DesiredValue){
					#Write-Verbose $label
					$noOfNSXTConfigurations++
					$authPolicyConfig.api_max_auth_failures = $configData.$product.$label.DesiredValue
				}
				
				$label = "VI-NET-AUD-01497"
				if($authPolicyConfig.cli_failed_auth_lockout_period -ne $configData.$product.$label.DesiredValue){
					#Write-Verbose $label
					$noOfNSXTConfigurations++
					$authPolicyConfig.cli_failed_auth_lockout_period = $configData.$product.$label.DesiredValue
				}
				$label = "VI-NET-AUD-01498"
				if($authPolicyConfig.cli_max_auth_failures -ne $configData.$product.$label.DesiredValue){
					#Write-Verbose $label
					$noOfNSXTConfigurations++
					$authPolicyConfig.cli_max_auth_failures = $configData.$product.$label.DesiredValue
				}
				$label = "VI-NET-AUD-01421"
				if($authPolicyConfig.minimum_password_length -ne $configData.$product.$label.DesiredValue){
					#Write-Verbose $label
					$noOfNSXTConfigurations++
					$authPolicyConfig.minimum_password_length = $configData.$product.$label.DesiredValue
				}
				
				$body = $authPolicyConfig | ConvertTo-Json

				$uri = "https://$nsxt/api/v1/node/aaa/auth-policy"
				PutNsxtAPIMethod $uri $headers $body
				
				
				$label = "VI-NET-AUD-01477"
				$uri = "https://$nsxt/api/v1/node/services/ssh"
				$sshConfig = GetNsxtAPIMethod $uri $headers
				
				$uri = "https://$nsxt/api/v1/node/services/ssh/status"
				$sshStatusConfig = GetNsxtAPIMethod $uri $headers

				if($sshConfig.service_properties.start_on_boot -ne $false -OR $sshStatusConfig.runtime_state -ne "stopped"){
					#Write-Verbose $label
					$noOfNSXTConfigurations++
					if($sshConfig.service_properties.start_on_boot -ne $false){
						$sshConfig.service_properties.start_on_boot=$false
						$body = $sshConfig | ConvertTo-Json
						$uri = "https://$nsxt/api/v1/node/services/ssh"
						PutNsxtAPIMethod $uri $headers $body
					}
					if($sshStatusConfig.runtime_state -ne "stopped"){
						$uri = "https://$nsxt/api/v1/node/services/ssh?action=stop"
						PostNsxtAPIMethod $uri $headers
					}	
				}
				
				$label = "VI-NET-AUD-01501"
				$uri = "https://$nsxt/api/v1/cluster/api-service"
				$tlsConfig = GetNsxtAPIMethod $uri $headers
				if(($tlsConfig.protocol_versions | Where-Object {$_.name -eq "TLSv1.1"}).enabled -eq $true){
					($tlsConfig.protocol_versions | Where-Object {$_.name -eq "TLSv1.1"}).enabled = $false
					$body = $tlsConfig | ConvertTo-Json
					PutNsxtAPIMethod $uri $headers $body
					$noOfNSXTConfigurations++
				}
				
				$label = "VI-NET-AUD-01508"
				$uri = "https://$nsxt/policy/api/v1/infra/global-config"
				$fipsConfig = GetNsxtAPIMethod $uri $headers
				if($fipsConfig.fips.lb_fips_enabled -eq $false){
					$fipsConfig.fips.lb_fips_enabled = $true
					$body = $fipsConfig | ConvertTo-Json
					PatchNsxtAPIMethod $uri $headers $body
					$noOfNSXTConfigurations++
				}
				
				<#$label = "VI-NET-AUD-01445"
				$uri = "https://$nsxt/api/v1/node/services/ntp"
				$ntpConfig = GetNsxtAPIMethod $uri $headers

				if(!$ntpConfig.service_properties.servers -OR $inputSpecData.$product.$label.DesiredValue -eq "No"){
					$uri = "https://$nsxt/api/v1/node/services/ntp"
					$ntpConfig.service_properties.servers
					
					PostNsxtAPIMethod $uri $headers $body
					$noOfNSXTConfigurations++
				}#>
				
				$totalNoOfNsxtConfigurations += $noOfNSXTConfigurations
				
			}
			
			if($totalNoOfNsxtConfigurations -gt 0){
				$remediationMessage = "Please re-run Audit-NsxtManager to check the status after Hardening"
			}
			else{
				$remediationMessage = "None of the Configurations got remediated"
			}
		}
		elseif($toHarden -like "n*"){
			$remediationMessage = "You must harden your NSXT Managers to be compliant with $RegulatoryStandard"
		}
		else{
			throw "Invalid Input. Please try again."
		}
		$nsxtHardeningDetails["TotalNoOfNsxtConfigurationsRemediated"] = $totalNoOfNsxtConfigurations
		$nsxtHardeningDetails["RemediationMessage"] = $remediationMessage 
		return $nsxtHardeningDetails
	}
	else{
		Throw "Please run Audit-NsxtManager with RegulatorStandard : $RegulatoryStandard and DomainName : $domainName before hardening"
	}
	
	
}