Function Harden-VcenterServer
{
	<#

	.SYNOPSIS
	Hardens vCenter Servers in VCF Environment.

	.DESCRIPTION
	This Cmdlet is used to harden vCenter Servers based on the regulatory standard and domain of interest.
	The regulatory standards tha are supported are  NIST, PCI and DISA.
	More support will be added in the future.
	
	.EXAMPLE
	Harden-VcenterServer -RegulatoryStandard NIST -DomainName <Domain Name> -ReportPath <Path where reports are saved and logs to be saved>
	Harden-VcenterServer -RegulatoryStandard PCI -DomainName <Domain Name> -ReportPath <Path where reports are saved and logs to be saved>
	Harden-VcenterServer -RegulatoryStandard DISA -DomainName <Domain Name> -ReportPath <Path where reports are saved and logs to be saved>

	.NOTES
	Connect to VCF Server using Connect-VCFServer before running Harden-VcenterServer Cmdlet.
	Run audit before hardening vCenter servers.
	
	#>
	
	Param(
		[ValidateSet("DISA","PCI","NIST",IgnoreCase=$true)]
		[Parameter(mandatory=$true)]
        [String]$RegulatoryStandard,
		[Parameter(mandatory=$true)]
        [String]$DomainName,
		[Parameter(mandatory=$true)]
        [String]$ReportPath
	)
	
	$domainName = $DomainName.trim()
	$vcenterHardeningDetails = @{}
	if($vcfSession.Session -eq 0){
		Throw "You are not currently connected to SDDC Manager. Please connect using Connect-VCFServer cmdlet."
	}
	
	#Clear-Host
	$fileNames = Get-ChildItem -Path $ReportPath
	if($fileNames.Name -Match $RegulatoryStandard+"_"+$domainName+"_"+"Vcenter"){
	
		$configFileName = $RegulatoryStandard.toLower()+"Config.json"
		$filePath = Join-Path -Path $PSScriptRoot -ChildPath $configFileName
		$configData = (Get-Content -Path $filePath -Raw )  | ConvertFrom-Json
		
		$inputFileName = "inputSpec.json"
		$inputFilePath = Join-Path -Path $PSScriptRoot -ChildPath $inputFileName
		$inputSpecData = (Get-Content -Path $inputFilePath -Raw )  | ConvertFrom-Json
		
		$product = "vCenter"
		
		$vcfCredentials = Select-Domain $domainName
		
		$totalNoOfvCenteriConfigurations = 0
		if($domainName -eq "All"){
				Write-Progress " Remediating vCenter Servers of $domainName Workload Domains:"
		}
		else{
			Write-Progress " Remediating vCenter Server of $domainName Workload Domain: $domainName"
		}					   
		$logName = $RegulatoryStandard.toUpper() + "_hardenVcenter"
		
		$toHarden = Read-Host -Prompt "This Operation will make Configurational changes on your vCenter Servers - Do you want to proceed - Yes/No?"
		if($toHarden -like "y*" ){
			Foreach($vc in $vcfCredentials["vCenterList"].fqdn){
				Connect-viserver -Server $vc -username $vcfCredentials["vcusername"] -password $vcfCredentials["vcpassword"] >> $ReportPath\\$logName.log
				Write-Progress "Remediating $vc..."
				$noOfvCenterConfigurations = 0
				
				$label = "VI-VC-AUD-00427"
				$advancedSetting = $configData.$product.$label.ParameterName
				$property = Get-AdvancedSetting -Entity $vc -Name $advancedSetting | Select-Object Name,Value
				if($property -and $property.value -ne $configData.$product.$label.DesiredValue)
				{
					Get-AdvancedSetting -Entity $vc -Name $advancedSetting | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfvCenterConfigurations++
				}
				
				$label = "VI-VC-AUD-00404"
				$advancedSetting = $configData.$product.$label.ParameterName
				$property = Get-AdvancedSetting -Entity $vc -Name $advancedSetting | Select-Object Name,Value
				if (!$property.Name){
					New-AdvancedSetting -Entity $vc -Name $advancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfvCenterConfigurations++
				}
				elseif($property.value -ne $configData.$product.$label.DesiredValue)
				{
					Get-AdvancedSetting -Entity $vc -Name $advancedSetting | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfvCenterConfigurations++
				}
				
				$label = "VI-VC-AUD-00428"
				$advancedSetting = $configData.$product.$label.ParameterName
				$property = Get-AdvancedSetting -Entity $vc -Name $advancedSetting | Select-Object Name,Value
				if (!$property.Name){
					New-AdvancedSetting -Entity $vc -Name $advancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfvCenterConfigurations++
				}
				elseif($property.value -ne $configData.$product.$label.DesiredValue)
				{
					Get-AdvancedSetting -Entity $vc -Name $advancedSetting | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfvCenterConfigurations++
				}
			
				$label = "VI-VC-AUD-00409"
				$niocs = Get-VDSwitch | Select-Object Name,@{N="NIOC Enabled";E={$_.ExtensionData.config.NetworkResourceManagementEnabled}}
				
				Foreach ($setting in $niocs){
					if ($setting."NIOC Enabled" -eq $false)
					{
						(Get-VDSwitch $setting.Name | Get-View).EnableNetworkResourceManagement($true) >> $ReportPath\$logName.log
						$noOfvCenterConfigurations++
					}
				}
				
				$label = "VI-VC-AUD-00405"
				$flag = 0
				$switchPromiscuousMode = Get-VDSwitch | Get-VDSecurityPolicy
				$portgroupPromiscuousMode = Get-VDPortgroup | Get-VDSecurityPolicy
				Foreach ($setting in $switchPromiscuousMode.AllowPromiscuous){
					if ($setting -eq "true")
					{
						Get-VDSwitch | Get-VDSecurityPolicy | Set-VDSecurityPolicy -AllowPromiscuous $false
						$flag = 1
					}
				}
				Foreach ($setting in $portgroupPromiscuousMode.AllowPromiscuous){
					if ($setting -eq "true")
					{
						Get-VDPortgroup | Where-Object {$_.IsUplink -eq $false} | Get-VDSecurityPolicy | Set-VDSecurityPolicy -AllowPromiscuous $false
						$flag = 1
					}
				}
				
				if($flag -eq 1)
				{
					$noOfvCenterConfigurations++
				}

				$label = "VI-VC-AUD-00407"
				$flag = 0
				$switchMacChanges = Get-VDSwitch | Get-VDSecurityPolicy
				$portgroupMacChanges = Get-VDPortgroup | Get-VDSecurityPolicy
				Foreach ($setting in $switchMacChanges.MacChanges){
					if ($setting -eq "true")
					{
						Get-VDSwitch | Get-VDSecurityPolicy | Set-VDSecurityPolicy -MacChanges $false
						$flag = 1
					}
				}
				Foreach ($setting in $portgroupMacChanges.MacChanges){
					if ($setting -eq "true")
					{
						Get-VDPortgroup | Where-Object {$_.IsUplink -eq $false} | Get-VDSecurityPolicy | Set-VDSecurityPolicy -MacChanges $false
						$flag = 1
					}
				}
				if($flag -eq 1)
				{
					$noOfvCenterConfigurations++
				}
						
				$label = "VI-VC-AUD-00450"
				$flag = 0
				$switchForgedTransmits = Get-VDSwitch | Get-VDSecurityPolicy
				$portgroupForgedTransmits = Get-VDPortgroup | Where-Object {$_.IsUplink -eq $false} | Get-VDSecurityPolicy
				Foreach ($setting in $switchForgedTransmits.ForgedTransmits){
					if ($setting -eq "true")
					{
						Get-VDSwitch | Get-VDSecurityPolicy | Set-VDSecurityPolicy -ForgedTransmits $false
						$flag = 1
					}
				}
				Foreach ($setting in $portgroupForgedTransmits.ForgedTransmits){
					if ($setting -eq "true")
					{
						Get-VDPortgroup | Where-Object {$_.IsUplink -eq $false} | Get-VDSecurityPolicy | Set-VDSecurityPolicy -ForgedTransmits $false
						$flag = 1
					}
				}
				
				if($flag -eq 1)
				{
					$noOfvCenterConfigurations++
				}

				$label = "VI-VC-AUD-01200"
				$vds = Get-VDSwitch
				$vdsSetting = $vds.ExtensionData.Config.HealthCheckConfig
				Foreach ($setting in $vdsSetting){
					if($setting.Enable -ne $False){
						Get-View -ViewType DistributedVirtualSwitch | Where-Object {($_.config.HealthCheckConfig | Where-Object {$_.enable -notmatch "False"})}| ForEach-Object {$_.UpdateDVSHealthCheckConfig(@((New-Object Vmware.Vim.VMwareDVSVlanMtuHealthCheckConfig -property @{enable=0}),(New-Object Vmware.Vim.VMwareDVSTeamingHealthCheckConfig -property @{enable=0})))}
						$noOfvCenterConfigurations++
					}
				}


				$label = "VI-VC-AUD-01221"
				$advancedSetting = $configData.$product.$label.ParameterName
				$property = Get-AdvancedSetting -Entity $vc -Name $advancedSetting | Select-Object Name,Value
				if ($property.value -ne $True)
				{
					Get-AdvancedSetting -Entity $vc -Name $advancedSetting | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
					$noOfvCenterConfigurations++
				}
				
				Connect-SsoAdminServer -Server $vc -user $vcfCredentials["vcusername"] -password $vcfCredentials["vcpassword"] >> $ReportPath\\$logName.log

				$label = "VI-VC-AUD-00403"
				$ssoPasswordPolicy = Get-SsoPasswordPolicy
				if($ssoPasswordPolicy.ProhibitedPreviousPasswordsCount -lt $configData.$product.$label.DesiredValue){
					Get-SsoPasswordPolicy | Set-SsoPasswordPolicy -ProhibitedPreviousPasswordsCount $configData.$product.$label.DesiredValue >> $ReportPath\$logName.log
					$noOfvCenterConfigurations++
				}
				
				$label = "VI-VC-AUD-00408"
				$ssoPasswordPolicy = Get-SsoPasswordPolicy
				if($ssoPasswordPolicy.MinUppercaseCount -lt $ConfigData.$product.$label.DesiredValue){
					Get-SsoPasswordPolicy | Set-SsoPasswordPolicy -MinUppercaseCount $configData.$product.$label.DesiredValue >> $ReportPath\$logName.log
					$noOfvCenterConfigurations++
				}
				
				$label = "VI-VC-AUD-00413"
				$ssoPasswordPolicy = Get-SsoPasswordPolicy
				if($ssoPasswordPolicy.MinLowercaseCount -lt $configData.$product.$label.DesiredValue){
					Get-SsoPasswordPolicy | Set-SsoPasswordPolicy -MinLowercaseCount $configData.$product.$label.DesiredValue >> $ReportPath\$logName.log
					$noOfvCenterConfigurations++
				}
				$label = "VI-VC-AUD-00432"
				$ssoPasswordPolicy = Get-SsoPasswordPolicy
				if($ssoPasswordPolicy.MinSpecialCharCount -lt $configData.$product.$label.DesiredValue){
					Get-SsoPasswordPolicy | Set-SsoPasswordPolicy -MinSpecialCharCount $configData.$product.$label.DesiredValue >> $ReportPath\$logName.log
					$noOfvCenterConfigurations++
				}
				
				$label = "VI-VC-AUD-00433"
				$ssoPasswordPolicy = Get-SsoPasswordPolicy
				if($ssoPasswordPolicy.MinNumericCount -lt $configData.$product.$label.DesiredValue){
					Get-SsoPasswordPolicy | Set-SsoPasswordPolicy -MinNumericCount $configData.$product.$label.DesiredValue >> $ReportPath\$logName.log
					$noOfvCenterConfigurations++
				}
				
				$label = "VI-VC-AUD-00421"
				$ssoPasswordPolicy = Get-SsoPasswordPolicy
				if($ssoPasswordPolicy.PasswordLifetimeDays -ne $configData.$product.$label.DesiredValue){
					Get-SsoPasswordPolicy | Set-SsoPasswordPolicy -PasswordLifetimeDays $configData.$product.$label.DesiredValue >> $ReportPath\$logName.log
					$noOfvCenterConfigurations++
				}
				$label = "VI-VC-AUD-00434"
				$ssoLockoutPolicy = Get-SsoLockoutPolicy
				if($ssoLockoutPolicy.FailedAttemptIntervalSec -lt $configData.$product.$label.DesiredValue){
					Get-SsoLockoutPolicy | Set-SsoLockoutPolicy -FailedAttemptIntervalSec $configData.$product.$label.DesiredValue >> $ReportPath\$logName.log
					$noOfvCenterConfigurations++
				}
				
				$label = "VI-VC-AUD-00435"
				if($ssoLockoutPolicy.AutoUnlockIntervalSec -ne $configData.$product.$label.DesiredValue){
					Get-SsoLockoutPolicy | Set-SsoLockoutPolicy -AutoUnlockIntervalSec $configData.$product.$label.DesiredValue >> $ReportPath\$logName.log
					$noOfvCenterConfigurations++
				}
				
				$label = "VI-VC-AUD-00436"
				if($ssoLockoutPolicy.MaxFailedAttempts -ne $configData.$product.$label.DesiredValue){
					Get-SsoLockoutPolicy | Set-SsoLockoutPolicy -MaxFailedAttempts $configData.$product.$label.DesiredValue >> $ReportPath\$logName.log
					$noOfvCenterConfigurations++
				}
				
				Disconnect-SsoAdminServer -Server $vc
				
				<#$label = "VI-VC-AUD-01201"
				$nativeVLANId = 1
				$vlanConfig = Get-VDPortgroup | Select-Object Name, VlanConfiguration
				$flag=0
				$newVlanConfigs = $inputSpecData.$product.$label.DesiredValue.split(",")
				Foreach ($setting in $vlanConfig){
					if($setting.VlanConfiguration.vlanid -eq $nativeVLANId)
					{
						foreach($newVlan in $newVlanConfigs){
							if($newVlan.split(":")[0] -eq $setting.Name){
								Get-VDPortgroup $setting.Name | Set-VDVlanConfiguration -VlanId $newVlan.split(":")[1] >> $ReportPath\$logName.log
								$flag=1
							}
						}
					}
				}
				if($flag -eq 1){
					$noOfvCenterConfigurations++
				}
				
				$label = "VI-VC-AUD-01202"
				$reservedVLANId = 2
				$vlanConfig = Get-VDPortgroup | Select-Object Name, VlanConfiguration
				$flag=0
				$newVlanConfigs = $inputSpecData.$product.$label.DesiredValue.split(",")
				Foreach ($setting in $vlanConfig){
					if($setting.VlanConfiguration.vlanid -eq $reservedVLANId)
					{
						foreach($newVlan in $newVlanConfigs){
							if($newVlan.split(":")[0] -eq $setting.Name){
								Get-VDPortgroup $setting.Name | Set-VDVlanConfiguration -VlanId $newVlan.split(":")[1] >> $ReportPath\$logName.log
								$flag=1
							}
						}
					}
					
				}
				if($flag -eq 1){
					$noOfvCenterConfigurations++
				}
				#>
				$label = "VI-VC-AUD-01238"
				$snmpReceivers = Get-AdvancedSetting -Entity $vc -Name "snmp*" | Where-Object {$_.Name -like "snmp.receiver.*.enabled*" -and $_.Value -eq $true}
				if($snmpReceivers){
					Get-AdvancedSetting -Entity $vc -Name "snmp*" | Where-Object {$_.Name -like "snmp.receiver.*.enabled*"  -and $_.Value -eq $true} | Set-AdvancedSetting -Value $false -Confirm:$false >> $ReportPath\$logName.log
					$noOfvCenterConfigurations++
				}
				
				<#$label = "VI-VC-AUD-00422"
				$VCFComponents = Get-VCFCredential
				Foreach ($component in $VCFComponents){
				#if($component.resource.resourceType -eq "VCENTER" -and $component.resource.domainName -eq $domainName -and $component.resource.resourceName -eq $vc -and $component.credentialType -eq "SSH"){
					if($component.resource.resourceType -eq "VCENTER" -and $component.resource.resourceName -eq $vc -and $component.credentialType -eq "SSH"){
						$domainDetails = getDomainDetails($component.resource.domainName)
						$vCenterVmName = $component.resource.resourceName.split(".")[0]
						$vCenterVmUsername = $component.username
						$vCenterVmPassword = $component.password
					}
				}
			
				if($domainDetails["domainType"] -eq "VI"){
					Write-Verbose "Management vCenter:"$managementVc
					$vcConnection = Connect-viserver -Server $managementVc -username $vcfCredentials["vcusername"] -password $vcfCredentials["vcpassword"] -ErrorAction SilentlyContinue
					if($vcConnection)
					{
						$vm = Get-VM -Name $vCenterVmName
						$script = "grep session\.timeout /etc/vmware/vsphere-ui/webclient.properties"
						$noOfvCenterConfigurations++
						$output = Invoke-VMScript -vm $vm -ScriptText $script  -ScriptType Bash -GuestUser $vCenterVmUsername -GuestPassword $vCenterVmPassword
						disconnect-viserver -Server $managementVc -Confirm:$false
					}
				}
				else{
					$vm = Get-VM -Name $vCenterVmName
					$script = "grep session\.timeout /etc/vmware/vsphere-ui/webclient.properties"
					$noOfvCenterConfigurations++
					$output = Invoke-VMScript -vm $vm -ScriptText $script  -ScriptType Bash -GuestUser $vCenterVmUsername -GuestPassword $vCenterVmPassword
				}

				if($output.Contains("session.timeout")){
					$timeout = $output.Split("=")[1].split("")[1]
				}
				if($timeout -ne 10){
					$script = @"
					sed -i 's/session.timeout = $timeout/session.timeout = 10/' /etc/vmware/vsphere-ui/webclient.properties
					export VMWARE_PYTHON_PATH=/usr/lib/vmware/site-packages
					export VMWARE_LOG_DIR=/var/log
					export VMWARE_DATA_DIR=/storage
					export VMWARE_CFG_DIR=/etc/vmware
					service-control --stop vsphere-ui
					service-control --start vsphere-ui
"@
					Invoke-VMScript -vm $vm -ScriptText $script  -ScriptType Bash -GuestUser $vCenterVmUsername -GuestPassword $vCenterVmPassword >> $ReportPath\$logName.log
					$noOfvCenterConfigurations++
				}#>
				
				Write-Verbose "$noOfvCenterConfigurations configurations on $vc got remediated"
				$totalNoOfvCenteriConfigurations += $noOfvCenterConfigurations
			
				disconnect-viserver -Server $vc -Confirm:$false
			}
		
			if($totalNoOfvCenteriConfigurations -gt 0){
				$remediationMessage = "Please re-run Audit-VcenterServer to check the status after Hardening"
			}
			else{
				$remediationMessage = "None of the Configurations got remediated"
			}
		}
		elseif($toHarden -like "n*"){
			$remediationMessage = "You must harden your vCenter Servers to be compliant with $RegulatoryStandard"
		}
		else{
			throw "Invalid Input. Please try again."
		}
		$vcenterHardeningDetails["TotalNoOfVcenterConfigurationsRemediated"] = $totalNoOfvCenteriConfigurations
		$vcenterHardeningDetails["RemediationMessage"] = $remediationMessage
		return $vcenterHardeningDetails
	}
	else{
		Throw "Please run Audit-VcenterServer with RegulatorStandard : $RegulatoryStandard and DomainName : $domainName before hardening"
	}
	
}