# Generated on: 9/16/2021
# Updated on : 02/16/2022 - Included Remediation for all the components.
# Updated on : 02/28/2022 - Added Domain selection logic for multiple domains issues.
# Updated on : 03/07/2022 - Fixed Hardening issues of Harden-ESXiHosts cmdlet and updated config json files.
# Updated on : 03/23/2022 - Added 10 new configurations of vCenter Server for automation which are API based.
# Updated on : 03/23/2022 - Added fix to NSX-T gateway issue.
# Updated on : 05/02/2022 - Added all the automatable Audit and automatable Non-Default configurations of all the components.
# Updated on : 13/05/2022 - Split ComplianceUtility.psm1 into  multiple files based on https://bugzilla.eng.vmware.com/show_bug.cgi?id=2969923.
# Updated on : 13/05/2022 - Updated prompting approach to parametrized approach  based on https://bugzilla.eng.vmware.com/show_bug.cgi?id=2970192.
# Updated on : 13/05/2022 - Updated SDDCManager cmdlets to read the data from inputSpec.json file instead of prompting approach.
# Updated on : 13/05/2022 - Updated All the cmdlets to handle hardening logics
# Updated on : 20/05/2022 - Addressed review comments phase 1 and SAST analysis warnings phase 1.
# Updated on : 27/05/2022 - Addressed review comments phase 2 and SAST analysis warnings phase 2.
# Updated on : 27/05/2022 - Fixed excel report issue. 

#This is a Powershell module for VCF Compliance.

$Global:vcfSession = @{}
$vcfSession.Session = 0
. $PSScriptRoot\Audit-ESXiHost.ps1
. $PSScriptRoot\Audit-VcenterServer.ps1
. $PSScriptRoot\Audit-VirtualMachine.ps1
. $PSScriptRoot\Audit-NsxtManager.ps1
. $PSScriptRoot\Audit-SDDCManager.ps1
. $PSScriptRoot\Audit-All.ps1
. $PSScriptRoot\Harden-ESXiHost.ps1
. $PSScriptRoot\Harden-VcenterServer.ps1
. $PSScriptRoot\Harden-VirtualMachine.ps1
. $PSScriptRoot\Harden-NsxtManager.ps1
. $PSScriptRoot\Harden-SDDCManager.ps1
. $PSScriptRoot\Harden-All.ps1

Function getDomainDetails($domainName){
	$domainDetails = @{}
	$workloadDomains = Get-VCFWorkloadDomain
	foreach($dom in $workloadDomains){
		if($dom.name -eq $domainName){
			$domainDetails["domainId"] = $dom.id
			$domainDetails["domainName"] = $dom.Name
			$domainDetails["domainType"] = $dom.type
			break
		}
	}
	return $domainDetails
}
Function Generate-Report($hashKeys,$jsonName,$RegulatoryStandard,$destination){
	$report = foreach($hashKey in $hashKeys.keys){
		$innerKeys = $hashKeys[$hashKey]
		foreach($innerKey in $innerKeys.keys){
			$resultKey = $innerKeys[$innerKey]
			
			if($RegulatoryStandard -eq "DISA"){
				[PSCustomObject]@{
					Hostname = $hashKey
					ConfLabel = $innerKey
					Description = $resultKey.description
					ParameterName = $resultKey.parametername
					CurrentValue = $resultKey.CurrentValue
					DesiredValue = $resultKey.desiredvalue
					ComplianceStatus = $resultKey.compliancestate
					ControlID = $resultKey.ControlID
					SRGID = $resultKey.SRGID
				}
			}
			else{
				[PSCustomObject]@{
					Hostname = $hashKey
					ConfLabel = $innerKey
					Description = $resultKey.description
					ParameterName = $resultKey.parametername
					CurrentValue = $resultKey.CurrentValue
					DesiredValue = $resultKey.desiredvalue
					ComplianceStatus = $resultKey.compliancestate
					Citation = $resultKey.citation
				}
			}
				
		}
    }
    
	$excelFileName = $jsonName +"_"+ (Get-Date -Format "dd-MM-yyyy-hh-mm-ss")+".xlsx"

	$critFormat = New-ConditionalText -Text "Pass" -Range "G:G" -ForeGroundColor Black -BackgroundColor Green
	$critFormat1 = New-ConditionalText -Text "Fail" -Range "G:G" -ForeGroundColor Black -BackgroundColor Red
	
	$excelPath = Join-Path -Path $destination -ChildPath $excelFileName
	
	$params = @{
	WorksheetName = "AuditResults"}
	
	$excelOutput = $report | Export-Excel -Path $excelPath -WorksheetName "AuditResults" -ConditionalFormat $critFormat, $critFormat1 -AutoSize -AutoFilter -FreezeTopRow -BoldTopRow -IncludePivotTable -PivotRows Hostname, ComplianceStatus, ConfLabel -PivotData ComplianceStatus -PassThru
	$ws = $excelOutput.Workbook.Worksheets[$params.WorksheetName]
	$ws.Column(5).Width = 30
	$ws.Column(6).Width = 30
	$ws.Column(5).Style.HorizontalAlignment = "Left"
	$ws.Column(6).Style.HorizontalAlignment = "Left"
	$ws.Column(8).Style.HorizontalAlignment = "Left"
	$ws.Column(5).Style.WrapText= $true
	$ws.Column(6).Style.WrapText= $true
	Close-ExcelPackage $excelOutput
}

Function Select-Domain($domainName){
	$vcfCredentials = @{}
	if($domainName -eq "All"){
		$nsxtClusterNodesList = @{}
		$vcfCredentials["vCenterList"] = Get-VCFvCenter
		$nsxtCluster = Get-VCFNsxtCluster
		foreach($cluster in $nsxtCluster){
			foreach($node in $cluster.nodes.fqdn){
				$nsxtClusterNodesList[$node] = $cluster.id
			}
		}
		$vcfCredentials["nsxtClusterNodesList"]  = $nsxtClusterNodesList
		$nsxtNodes = $nsxtCluster | Select-Object nodes
		$vcfCredentials["nsxtNodesList"] = $nsxtNodes.nodes
		$VCFComponents = Get-VCFCredential
		Foreach ($component in $VCFComponents){
			if($component.resource.resourceType -eq "PSC"){
				
				$vcfCredentials["managementVc"] = $component.resource.resourceName
				$vcfCredentials["vcusername"] = $component.username
				$vcfCredentials["vcpassword"] = $component.password
					   
			}
			if($component.resource.resourceType -eq "ESXI"){
				
				$vcfCredentials["esxiusername"] = $component.username
				$vcfCredentials["esxipassword"] = $component.password
			}
		}
	}
	else{
		$domainDetails = getDomainDetails($domainName)
		if($domainDetails["domainName"]){
			$vcfCredentials["vCenterList"] = Get-VCFvCenter | Where-Object {$_.domain.id -eq $domainDetails["domainId"]}
			$nsxtNodes = Get-VCFNsxtCluster | Where-Object {$_.domains.name -eq $domainName} | Select-Object nodes
			$vcfCredentials["nsxtUsername"] = Get-VCFCredential | Where-Object {$_.credentialType -eq "API" -and $_.resource.resourceType -eq "NSXT_MANAGER" -and $_.resource.domainName -eq $domainName} | Select-Object username
			$vcfCredentials["nsxtPassword"] = Get-VCFCredential | Where-Object {$_.credentialType -eq "API" -and $_.resource.resourceType -eq "NSXT_MANAGER" -and $_.resource.domainName -eq $domainName} | Select-Object password
			$vcfCredentials["nsxtNodesList"] = $nsxtNodes.nodes
			$VCFComponents = Get-VCFCredential								 
			Foreach ($component in $VCFComponents){
				if($component.resource.resourceType -eq "PSC"){
				
					$vcfCredentials["managementVc"] = $component.resource.resourceName
					$vcfCredentials["vcusername"] = $component.username
					$vcfCredentials["vcpassword"] = $component.password		   
				}
				if($component.resource.resourceType -eq "ESXI"){
				
					$vcfCredentials["esxiusername"] = $component.username
					$vcfCredentials["esxipassword"] = $component.password
				}
			}
		}
		else{
			throw "VCF domain $domainName not found, Please input a valid domain name."
		}	
	}
	return $vcfCredentials
}

<#Function Configure-SSL{
	add-type @"
		using System.Net;
		using System.Security.Cryptography.X509Certificates;
		public class TrustAllCertsPolicy : ICertificatePolicy {
			public bool CheckValidationResult(
				ServicePoint srvPoint, X509Certificate certificate,
				WebRequest request, int certificateProblem) {
				return true;
			}
		}
"@
	[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
	[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
	
}#>

Function Get-NSXTFirewallSectionID{

	$nsxtFirewallSectionIds = @{}
	$firewallService = Get-NsxtService -Name "com.vmware.nsx.firewall.sections"
	$firewallServices = $firewallService.list().results

	foreach($service in $firewallServices)
	{
		if($service.display_name -like "*tier0*"){
			$nsxtFirewallSectionIds["tier0Id"] = $service.id
		}
		elseif($service.display_name -like "*tier1*"){
			$nsxtFirewallSectionIds["tier1Id"] = $service.id
		}
		else{
			$nsxtFirewallSectionIds["dfwId"] = $service.id
		}
	}
	return $nsxtFirewallSectionIds
}

Function Install-PreRequisites{
	[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
	Set-PSRepository -Name "PSGallery" -InstallationPolicy Trusted

	$powerVCF = Get-Package -Name "PowerVCF" -ErrorAction SilentlyContinue
	if($powerVCF.Name){
		Write-Output "PowerVCF module is already installed"
	}
	else{
		Write-Output "PowerVCF module is not installed"
		Write-Progress "Installing PowerVCF module..."
		Install-Module -Name PowerVCF -MinimumVersion 2.2.0 -Force -SkipPublisherCheck
		Write-Output "PowerVCF module is successfully installed"
	}
	$powerCLI = Get-Package -Name "VMware.PowerCLI" -ErrorAction SilentlyContinue
	if($powerCLI.Name){
		Write-Output "PowerCLI module is already installed"
	}
	else{
		Write-Output "PowerCLI module is not installed"
		Write-Progress "Installing PowerCLI module..."
		Install-Module -Name VMware.PowerCLI -SkipPublisherCheck
		Write-Output "PowerCLI module is successfully installed"
	}
	$importExcel = Get-Package -Name "ImportExcel" -ErrorAction SilentlyContinue
	if($importExcel.Name){
		Write-Output "ImportExcel module is already installed"
	}
	else{
		Write-Output "ImportExcel module is not installed"
		Write-Progress "Installing ImportExcel module..."
		Install-Module -Name ImportExcel -MinimumVersion 7.5.0 -SkipPublisherCheck
		Write-Output "ImportExcel module is successfully installed"
	}

	$vmwareVsphereAsoAdmin = Get-Package -Name "VMware.vSphere.SsoAdmin" -ErrorAction SilentlyContinue
	if($vmwareVsphereAsoAdmin.Name){
		Write-Output "VMware.vSphere.SsoAdmin module is already installed"
	}
	else{
		Write-Output "VMware.vSphere.SsoAdmin module is not installed"
		Write-Progress "Installing VMware.vSphere.SsoAdmin module..."
		Install-Module -Name VMware.vSphere.SsoAdmin -MinimumVersion 1.3.8 -SkipPublisherCheck
		Write-Output "VMware.vSphere.SsoAdmin module is successfully installed"
	}
}

Function Connect-VCFServer{
	
	$sddcServer = Read-Host -Prompt "Enter SDDC Manager's IP/FQDN"
	$sddcUsername = Read-Host -Prompt "Enter SDDC Manager's Username"
	$sddcPassword = Read-Host -Prompt "Enter SDDC Manager's Password" -AsSecureString
	$secretPassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($sddcPassword))
        Install-PreRequisites
	$vcfDetails = @{}
	$vcfSession["Session"] = 0
	
	$vcfToken = Request-VCFToken -fqdn $sddcServer -username $sddcUsername -password $secretPassword
	if($vcfToken){
		$vcfSession.Session = 1
		$vcfSession.SddcServer = $sddcServer
		$vcfSession.SddcUsername = $sddcUsername
		$vcfSession.SecretPassword = $secretPassword
		$vcfDetails["Server"] = $sddcServer
		$vcfDetails["Username"] = $sddcUsername
	}
	else
	{
		Write-Host "Cannot complete login due to incorrect username or password"
	}
	
	return $vcfDetails
}

Function Set-Hash($citation, $confDesc,$parameterName,$currentValue,$desiredValue,$complianceState){
	$hashValue = @{}
	$hashValue["Citation"] = $citation
	$hashValue["Description"] = $confDesc
	$hashValue["ParameterName"] = $parameterName
	$hashValue["CurrentValue"] = $currentValue
	$hashValue["DesiredValue"] = $desiredValue
	$hashValue["ComplianceState"] = $complianceState
	return $hashValue
}

Function Set-DISAHash($srgID,$controlID,$confDesc,$parameterName,$currentValue,$desiredValue,$complianceState){
	$hashValue = @{}
	$hashValue["SRGID"] = $srgID
	$hashValue["ControlID"] = $controlID
	$hashValue["Description"] = $confDesc
	$hashValue["ParameterName"] = $parameterName
	$hashValue["CurrentValue"] = $currentValue
	$hashValue["DesiredValue"] = $desiredValue
	$hashValue["ComplianceState"] = $complianceState
	return $hashValue
}

Function generateAccessToken($sddcServer, $sddcUsername, $secretPassword){
	$body = @{
		username = $sddcUsername
		password = $secretPassword
	} | ConvertTo-Json
	
	$tokenParams = @{
		Method = "Post"
		uri = "https://$sddcServer/v1/tokens"
		ContentType = "application/json"
		Body = $body
	}
	
	if($PSEdition -eq "Desktop"){
		#[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
		#[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
		[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;
    If (!("TrustAllCertificatePolicy" -as [type])) {
    add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertificatePolicy : ICertificatePolicy {
        public TrustAllCertificatePolicy() {}
        public bool CheckValidationResult(
            ServicePoint sPoint, X509Certificate certificate,
            WebRequest wRequest, int certificateProblem) {
            return true;
        }
    }
"@
}
    [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertificatePolicy
		$token = try {
			Invoke-RestMethod @tokenParams
		} 
		catch{
			$_.Exception.Response
		}
		$accessToken = $token.accessToken
	}
	if($PSEdition -eq "Core"){
		$token = try {
			Invoke-RestMethod @tokenParams -SkipCertificateCheck
		} 
		catch{
			$_.Exception.Response
		}
		$accessToken = $token.accessToken
	}
	$headers = @{
		Authorization="Bearer $accessToken"
	}
	return $headers
	
}

Function generateAPISessionKey($server,$vcUser,$vcPass){		
	$pair = "$($vcUser):$($vcPass)"
	$encodedCreds = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($pair))
	$basicAuthValue = "Basic $encodedCreds"

	$headers = @{
		Authorization = $basicAuthValue
	}

	$apiSessionParams = @{
		uri = "https://$server/api/session"
		Headers = $headers
		Method = "Post"
	}

	$apiSessionKey = try {
		Invoke-RestMethod @apiSessionParams
	} 
	catch{
		$_.Exception.Response
	}
	
	return $apiSessionKey
}

Function GetvCenterAPIMethod($uri,$apiSessionKey){

	$vCenterSettingsParams = @{
		uri = $uri
		Headers = @{'vmware-api-session-id'=$apiSessionKey}
		Method = "Get"
	}

	$vCenterSettingsConfig = try {
		Invoke-RestMethod @vCenterSettingsParams
	} 
	catch{
		$_.Exception.Response
	}
	
	return $vCenterSettingsConfig
			
}

Function PostvCenterAPIMethod($uri,$apiSessionKey,$body){
	$vCenterSettingsParams = @{
		uri = $uri
		Headers = @{'vmware-api-session-id'=$apiSessionKey}
		Method = "Post"
		ContentType = "application/json"
		Body = $body
	}

	$vCenterSettingsConfig = try {
		Invoke-RestMethod @vCenterSettingsParams
	} 
	catch{
		$_.Exception.Response
	}
	
	return $vCenterSettingsConfig
}

Function GetNsxtAPIMethod($uri,$headers){
	$nsxtSettingsParams = @{
		uri = $uri
		Headers = $headers
		Method = "Get"
	}
	if($PSEdition -eq "Desktop"){
		[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;
    If (!("TrustAllCertificatePolicy" -as [type])) {
    add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertificatePolicy : ICertificatePolicy {
        public TrustAllCertificatePolicy() {}
        public bool CheckValidationResult(
            ServicePoint sPoint, X509Certificate certificate,
            WebRequest wRequest, int certificateProblem) {
            return true;
        }
    }
"@
}
    [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertificatePolicy
		$nsxtSettingsConfig = try {
			Invoke-RestMethod @nsxtSettingsParams
		} 
		catch{
			$_.Exception.Response
		}
	}
	if($PSEdition -eq "Core"){
		$nsxtSettingsConfig = try {
			Invoke-RestMethod @nsxtSettingsParams -SkipCertificateCheck
		} 
		catch{
			$_.Exception.Response
			$flag = 1
		}
	}
	return $nsxtSettingsConfig
			
}

Function PostNsxtAPIMethod($uri,$headers){

	$nsxtSettingsParams = @{
		uri = $uri
		Headers = $headers
		Method = "Post"
	}
	if($PSEdition -eq "Desktop"){
		[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;
    If (!("TrustAllCertificatePolicy" -as [type])) {
    add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertificatePolicy : ICertificatePolicy {
        public TrustAllCertificatePolicy() {}
        public bool CheckValidationResult(
            ServicePoint sPoint, X509Certificate certificate,
            WebRequest wRequest, int certificateProblem) {
            return true;
        }
    }
"@
}
    [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertificatePolicy
		$nsxtSettingsConfig = try {
			Invoke-RestMethod @nsxtSettingsParams
		} 
		catch{
			$_.Exception.Response
		}
	}
	if($PSEdition -eq "Core"){
		$nsxtSettingsConfig = try {
			Invoke-RestMethod @nsxtSettingsParams -SkipCertificateCheck
		} 
		catch{
			$_.Exception.Response
		}
	}
			
}

Function PutNsxtAPIMethod($uri,$headers,$body){
	$nsxtSettingsParams = @{
		uri = $uri
		Headers = $headers
		Method = "Put"
		ContentType = "application/json"
		Body = $body
	}

	if($PSEdition -eq "Desktop"){
		[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;
    If (!("TrustAllCertificatePolicy" -as [type])) {
    add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertificatePolicy : ICertificatePolicy {
        public TrustAllCertificatePolicy() {}
        public bool CheckValidationResult(
            ServicePoint sPoint, X509Certificate certificate,
            WebRequest wRequest, int certificateProblem) {
            return true;
        }
    }
"@
}
    [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertificatePolicy
		$nsxtSettingsConfig = try {
			Invoke-RestMethod @nsxtSettingsParams
		} 
		catch{
			$_.Exception.Response
		}
	}
	if($PSEdition -eq "Core"){
		$nsxtSettingsConfig = try {
			Invoke-RestMethod @nsxtSettingsParams -SkipCertificateCheck
		} 
		catch{
			$_.Exception.Response
		}
	}
}

Function PatchNsxtAPIMethod($uri,$headers,$body){
	$nsxtSettingsParams = @{
		uri = $uri
		Headers = $headers
		Method = "Patch"
		ContentType = "application/json"
		Body = $body
	}

	if($PSEdition -eq "Desktop"){
		[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;
    If (!("TrustAllCertificatePolicy" -as [type])) {
    add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertificatePolicy : ICertificatePolicy {
        public TrustAllCertificatePolicy() {}
        public bool CheckValidationResult(
            ServicePoint sPoint, X509Certificate certificate,
            WebRequest wRequest, int certificateProblem) {
            return true;
        }
    }
"@
}
    [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertificatePolicy
		$nsxtSettingsConfig = try {
			Invoke-RestMethod @nsxtSettingsParams
		} 
		catch{
			$_.Exception.Response
		}
	}
	if($PSEdition -eq "Core"){
		$nsxtSettingsConfig = try {
			Invoke-RestMethod @nsxtSettingsParams -SkipCertificateCheck
		} 
		catch{
			$_.Exception.Response
		}
	}
	
}

Function GetSDDCManagerAPIMethod($uri,$headers){
	$sddcSettingsParams = @{
			uri = $uri
			Headers = $headers
			Method = "GET"
		}
	if($PSEdition -eq "Desktop"){
		[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;
    If (!("TrustAllCertificatePolicy" -as [type])) {
    add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertificatePolicy : ICertificatePolicy {
        public TrustAllCertificatePolicy() {}
        public bool CheckValidationResult(
            ServicePoint sPoint, X509Certificate certificate,
            WebRequest wRequest, int certificateProblem) {
            return true;
        }
    }
"@
}
    [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertificatePolicy
		$sddcSettingsConfig = try {
			Invoke-RestMethod @sddcSettingsParams
		} 
		catch{
			$_.Exception.Response
		}
	}
	if($PSEdition -eq "Core"){
		$sddcSettingsConfig = try {
			Invoke-RestMethod @sddcSettingsParams -SkipCertificateCheck
		} 
		catch{
			$_.Exception.Response
		}
	}
	return $sddcSettingsConfig
		
}























