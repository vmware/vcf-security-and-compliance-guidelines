Function Harden-All
{
	<#

	.SYNOPSIS
	Hardens all the components(ESXi, vCenter Server, Virtual Machine, NSX-T and SDDC Manager) in VCF Environment.

	.DESCRIPTION
	This Cmdlet is used to harden all the components(ESXi, vCenter Server, Virtual Machine, NSX-T and SDDC Manager) based on the regulatory standard and domain of interest.
	The regulatory standards supported are  NIST, PCI and DISA.
	More support will be added in the future.
	
	.EXAMPLE
	Harden-All -RegulatoryStandard NIST -DomainName <Domain Name> -ReportPath <Path where reports are saved and logs to be saved>
	Harden-All -RegulatoryStandard PCI -DomainName <Domain Name> -ReportPath <Path where reports are saved and logs to be saved>
	Harden-All -RegulatoryStandard DISA -DomainName <Domain Name> -ReportPath <Path where reports are saved and logs to be saved>

	.NOTES
	Connect to VCF Server using Connect-VCFServer before running Harden-All Cmdlet.
	Run audit all before hardening all.
	
	#>
	
	Param(
		[ValidateSet("DISA","PCI","NIST",IgnoreCase=$true)]
		[Parameter(mandatory=$true)]
        [String]$RegulatoryStandard,
		[Parameter(mandatory=$true)]
        [String]$DomainName,
		[Parameter(mandatory=$true)]
        [String]$ReportPath
	)
	
	$allHardenDetails = @{}
	if($vcfSession.Session -eq 0){
		Throw "You are not currently connected to SDDC Manager. Please connect using Connect-VCFServer cmdlet."
	}
	
	$totalNoOfRemediatedConfigurations = 0
	
	$esxiHardeningDetails = Harden-ESXiHost -RegulatoryStandard $RegulatoryStandard -DomainName $domainName -ReportPath $ReportPath
	$vcenterHardeningDetails = Harden-VcenterServer -RegulatoryStandard $RegulatoryStandard -DomainName $domainName -ReportPath $ReportPath
	$vmHardeningDetails = Harden-VirtualMachine -RegulatoryStandard $RegulatoryStandard -DomainName $domainName -ReportPath $ReportPath
	$nsxtHardeningDetails = Harden-NsxtManager -RegulatoryStandard $RegulatoryStandard -DomainName $domainName -ReportPath $ReportPath
	$sddcHardeningDetails = Harden-SDDCManager -RegulatoryStandard $RegulatoryStandard -ReportPath $ReportPath
	
	$totalNoOfRemediatedConfigurations = $esxiHardeningDetails["TotalNoOfEsxiConfigurationsRemediated"] + $vcenterHardeningDetails["TotalNoOfVcenterConfigurationsRemediated"] + $vmHardeningDetails["TotalNoOfVmConfigurationsRemediated"] + $nsxtHardeningDetails["TotalNoOfNsxtConfigurationsRemediated"] + $sddcHardeningDetails["TotalNoOfSddcConfigurationsRemediated"]
	if($totalNoOfRemediatedConfigurations -ne 0){
		$remediationMessage = "Please re-run Audit-All to check the status after Hardening"
	}
	else{
		$remediationMessage = "No Configurations to remediate"
	}
	
	$allHardenDetails["TotalNoOfConfigurationsRemediated"] = $totalNoOfRemediatedConfigurations
	$allHardenDetails["RemediationMessage"] = $remediationMessage
	#$remediateAllFlag = 0
	return $allHardenDetails
}