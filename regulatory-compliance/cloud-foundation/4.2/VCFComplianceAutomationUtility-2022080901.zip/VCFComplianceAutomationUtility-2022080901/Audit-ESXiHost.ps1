Function Audit-ESXiHost{
	<#

	.SYNOPSIS
	Audits ESXI Hosts in VCF Environment.

	.DESCRIPTION
	This Cmdlet is used to audit ESXI hosts based on the regulatory standard and the domain of interest.
	The regulatory standards supported are NIST, PCI and DISA.
	More support will be added in the future.
	
	.EXAMPLE
	Audit-ESXiHost -RegulatoryStandard NIST -DomainName <Domain Name> -ReportPath <Path where reports and logs get saved>
	Audit-ESXiHost -RegulatoryStandard PCI -DomainName <Domain Name> -ReportPath <Path where reports and logs get saved>
	Audit-ESXiHost -RegulatoryStandard DISA -DomainName <Domain Name> -ReportPath <Path where reports and logs get saved>

	.NOTES
	Connect to VCF Server using Connect-VCFServer before running Audit-ESXiHost Cmdlet.
	
	#>
	
	Param(
		[ValidateSet("DISA","PCI","NIST",IgnoreCase=$true)]
		[Parameter(mandatory=$true)]
        [String]$RegulatoryStandard,
		[Parameter(mandatory=$true)]
        [String]$DomainName,
		[Parameter(mandatory=$true)]
		[ValidateScript({Test-Path $_})]
        [String]$ReportPath
	)
	
	$domainName = $DomainName.trim()
	$compliant="Pass"
	$nonCompliant="Fail"
	$esxiAuditDetails = @{}
	if($vcfSession.Session -eq 0){
		Throw "You are not currently connected to SDDC Manager. Please connect using Connect-VCFServer cmdlet."
	}
	
	$configFileName = $RegulatoryStandard.toLower()+"Config.json"
	$filePath = Join-Path -Path $PSScriptRoot -ChildPath $configFileName
	$configData = (Get-Content -Path $filePath -Raw )  | ConvertFrom-Json
	
	$inputFileName = "inputSpec.json"
	$inputFilePath = Join-Path -Path $PSScriptRoot -ChildPath $inputFileName
	$inputSpecData = (Get-Content -Path $inputFilePath -Raw )  | ConvertFrom-Json
	
	$jsonName = $RegulatoryStandard.toUpper() + "_" + $domainName + "_ESXi"
	$product = "ESXi"
	
	$vcfCredentials = Select-Domain $domainName

	$esxiHashKey = @{}
	
	
	if($domainName -eq "All"){
			Write-Progress " Auditing ESXi Hosts of $domainName the Workload Domains:"
	}
	else{
		Write-Progress " Auditing ESXi Hosts of $domainName Workload Domain"
	}
	Foreach($vc in $vcfCredentials["vCenterList"].fqdn)
	{
		$logName = $RegulatoryStandard + "_auditESXi"
		$connection = Connect-viserver -Server $vc -username $vcfCredentials["vcusername"] -password $vcfCredentials["vcpassword"] -ErrorAction SilentlyContinue
		if($connection)
		{
			$esxiHosts = Get-VMHost
			
			Foreach($esxiHost in $esxiHosts)
			{
				Write-Progress "*********   Auditing $esxiHost ...   *********"
				$hostDetails = Get-VMHost $esxiHost
				$status = $hostDetails.ConnectionState.ToString()
				if($status -eq "Connected")
				{	   
					$esxiHashInnerKey = @{}
					$noOfEsxiConfigurations = 0
					
					$label = "VI-ESXi-AUD-00022"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if ($result.Value -ne $configData.$product.$label.DesiredValue)
					{
						$complianceState = $nonCompliant
					}
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.Value
					
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					
					$label = "VI-ESXi-AUD-00028"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-VMHostFirewallException | Where-Object {$_.Name -eq 'SSH Server' -and $_.Enabled -eq $true} | Select-Object Name,Enabled,@{N="AllIPEnabled";E={$_.ExtensionData.AllowedHosts.AllIP}}
					if($result.AllIPEnabled -ne $False){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.AllIPEnabled
					
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-00030"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name UserVars.SuppressShellWarning
					if($result.Value -ne $configData.$product.$label.DesiredValue){
						$complianceState = $nonCompliant
					}
					
					else{
						$complianceState = $compliant
					}
					$currentValue = $result.Value
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					
					$label = "VI-ESXi-AUD-00031"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = Get-VMHost $esxiHost | Select-Object Name,@{N="Lockdown";E={$_.Extensiondata.Config.LockdownMode}} 
					if($result.Lockdown -eq "lockdownDisabled"){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = [String]$result.Lockdown
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					
					$label = "VI-ESXi-AUD-00034"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name Security.AccountLockFailures
					
					if($result.Value -ne $configData.$product.$label.DesiredValue){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.Value
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-00038"
					$confLabel = "$RegulatoryStandard-$label"
					
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name UserVars.ESXiShellInteractiveTimeOut
					
					if($result.Value -ne $configData.$product.$label.DesiredValue){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.Value
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-00043"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name Net.BlockGuestBPDU
					if($result.Value -ne 1){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
					}
					$currentValue = $result.Value
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-00105"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-VMHostFirewallDefaultPolicy
					if($result.IncomingEnabled -ne $False){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.IncomingEnabled
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-00106"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-VMHostFirewallDefaultPolicy
					if($result.OutgoingEnabled -ne $False){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.OutgoingEnabled
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-00109"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name Security.PasswordHistory
					
					if($result.Value -ne $configData.$product.$label.DesiredValue){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.Value
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-00112"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-VMHostService | Where-Object {$_.Label -eq "ESXi Shell"}
					if($result.Policy -eq "on" -OR $result.Running -eq "True"){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					
					$currentValue = "Policy: " + $result.Policy + " " + "Running: " + $result.Running
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}

					$label = "VI-ESXi-AUD-00114"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-VMHostAuthentication
					if($result.DomainMembershipStatus -ne "Ok"){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = [String]$result.DomainMembershipStatus
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
										
					#Site-specifc configs,updated to read from inputSpec.json file. Madhu to review
					$label = "VI-ESXi-AUD-00122"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if($result.value -eq ""){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.value
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $inputSpecData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $inputSpecData.$product.$label.DesiredValue $complianceState
					}
					
					#Site-specifc configs,updated to read from inputSpec.json file. Madhu to review
					$label = "VI-ESXi-AUD-00123"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if($result.value -eq ""){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.value
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $inputSpecData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $inputSpecData.$product.$label.DesiredValue $complianceState
					}
					
					#New addition, Madhu to review and update required details as per inputSpec.json
					$label = "VI-ESXi-AUD-00125"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$view = $esxiHost | Get-View
                    $lockdown = Get-View $view.ConfigManager.HostAccessManager
                    $result = $lockdown.QueryLockdownExceptions()
			
					$currentValue = [String]$result
					
					if($result -and $inputSpecData.$product.$label.DesiredValue -eq "Yes"){
						$complianceState = $compliant
					}
					else{
						$complianceState = $nonCompliant
					}
				
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-00136"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$esxcli = Get-EsxCli -v2 -VMHost $esxiHost.Name
					$result = $esxcli.system.syslog.config.get.Invoke() | Select-Object LocalLogOutput,LocalLogOutputIsPersistent
					# $result = $esxiHost | Get-AdvancedSetting -Name Syslog.global.logDir
					#if($result.Value -ne "[] /scratch/log"){
					if($result.LocalLogOutputIsPersistent -ne $True){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.LocalLogOutputIsPersistent
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}

					$label = "VI-ESXi-AUD-00137"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name Config.HostAgent.plugins.hostsvc.esxAdminsGroup
					if($result.Value -eq "ESX Admins"){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.Value
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}

					$label = "VI-ESXi-AUD-00138"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name Mem.ShareForceSalting
					if($result.Value -ne 2){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.Value
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					#Site-specifc configs,updated to read from inputSpec.json file. Madhu to review
					$label = "VI-ESXi-AUD-00147"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-VMHostNTPServer
					if($result -and $inputSpecData.$product.$label.DesiredValue -eq "Yes"){
							$complianceState = $compliant	
					}
					else{
						$complianceState = $nonCompliant
							
					}
					
					$currentValue = $result
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $ConfigData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $ConfigData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-00148"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-VMHostService | Where-Object {$_.Label -eq "NTP Daemon"}
					if($result.Policy -eq "off"){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.Policy
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}

					$label = "VI-ESXi-AUD-00149"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-VMHostService | Where-Object {$_.Label -eq "NTP Daemon"}
					if($result.Running -ne $True){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.Running
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-00157"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$esxcli = Get-EsxCli -v2 -VMHost $esxiHost.Name
					$result = $esxcli.software.acceptance.get.Invoke()
					if($result -eq "CommunitySupported"){
							$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-00163"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name DCUI.Access
					if($result.Value -ne "root"){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.Value
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					#Site-specifc configs,updated to read from inputSpec.json file. Madhu to review
					$label = "VI-ESXi-AUD-00164"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName
					if($result.Value){
						$complianceState = $compliant	
					}
					
					else{
						$complianceState = $nonCompliant
						
					}
					$currentValue = $result.Value
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $ConfigData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $ConfigData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-00165"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name Security.AccountUnlockTime
					
					
					if($result.Value -ne $configData.$product.$label.DesiredValue){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.Value
					#$desiredValue = "root"
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-00166"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name Config.HostAgent.plugins.solo.enableMob
					if($result.Value -ne $False){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.Value
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-00168"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name UserVars.DcuiTimeOut
					if($result.Value -ne $configData.$product.$label.DesiredValue){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.Value
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					

					$label = "VI-ESXi-AUD-00169"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name Net.DVFilterBindIpAddress
					if($result.Value -ne ""){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.Value
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-00179"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name Config.HostAgent.log.level
					if($result.Value -ne "info"){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.Value
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-00564"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name UserVars.HostClientSessionTimeout
					if($result.Value -ne $configData.$product.$label.DesiredValue){
							$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.Value
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-01100"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$esxcli = Get-EsxCli -v2 -VMHost $esxiHost.Name
					$resultESXi = $esxcli.system.security.fips140.ssh.get.invoke()
					if($resultESXi.Enabled -ne "true"){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $resultESXi.Enabled
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-01107"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name UserVars.ESXiVPsDisabledProtocols
					if($result.Value -notmatch "tlsv1" -OR $result.Value -notmatch "tlsv1.1" -OR $result.Value -notmatch "sslv3"){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.Value
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}

					$label = "VI-ESXi-AUD-01110"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name UserVars.SuppressHyperthreadWarning
					if($result.Value -ne 0){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.Value
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-01112"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-VMHostService | Where-Object {$_.Label -eq "slpd"}
					if($result.Policy -eq "on" -OR $result.Running -eq "True"){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = "Policy: " + $result.Policy + " " + "Running: " + $result.Running
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					<# Madhu to update and review
					$label = "VI-ESXi-AUD-01114"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = Get-VMHost $esxiHost | Select-Object Name,@{N="Lockdown";E={$_.Extensiondata.Config.LockdownMode}}
					if($result.Lockdown -ne "lockdownDisabled"){
						(get-vmhost $esxiHost | get-view).ExitLockdownMode()
						Connect-VIServer -Server $esxiHost -username $vcfCredentials["esxiusername"] -password $vcfCredentials["esxipassword"] >> $ReportPath\\$logName.log
						$result = Get-VMHostSnmp -Server $esxiHost.Name | Select-Object *
						Disconnect-VIServer -Server $esxiHost.Name -Confirm:$false >> $ReportPath\\$logName.log
						(get-vmhost $esxiHost | get-view).EnterLockdownMode()
					}
					else{
						Connect-VIServer -Server $esxiHost -username $vcfCredentials["esxiusername"] -password $vcfCredentials["esxipassword"] >> $ReportPath\\$logName.log
						$result = Get-VMHostSnmp -Server $esxiHost.Name | Select-Object *
						Disconnect-VIServer -Server $esxiHost.Name -Confirm:$false >> $ReportPath\\$logName.log
					}
					if($result.Enabled -ne $False){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.Enabled
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}#>
					
					$label = "VI-ESXi-AUD-01115"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name Syslog.global.logCheckSSLCerts
					if($result.Value -ne "true"){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.Value
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-01116"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$result = $esxiHost | Get-AdvancedSetting -Name Config.HostAgent.vmacore.soap.sessionTimeout
					if($result.Value -ne 30){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $result.Value
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-ESXi-AUD-01117"
					$confLabel = "$RegulatoryStandard-$label"
					$noOfEsxiConfigurations++
					$esxcli = Get-EsxCli -v2 -VMHost $esxiHost.Name
					$resultESXi = $esxcli.system.security.fips140.rhttpproxy.get.invoke()
					if($resultESXi.Enabled -ne "true"){
						$complianceState = $nonCompliant	
					}
					
					else{
						$complianceState = $compliant
						
					}
					$currentValue = $resultESXi.Enabled
					if($RegulatoryStandard -eq "DISA"){
						$esxiHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$esxiHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$esxiHashKey[$esxiHost.Name] = $esxiHashInnerKey
					
				}
				else
				{
					$logMessage = "The Connection status of the ESXi Host: $esxiHost is: $status" 
					$logMessage >> $ReportPath\\$logName.log
				}
			}
			disconnect-viserver -Server $vc -Confirm:$false
		}
		else{
			$logMessage = "Resolve connectivity issue of $vc and run the audit again." 
			$logMessage >> $ReportPath\\$logName.log
		}
	}
	$fileName = $jsonName +"_"+ (Get-Date -Format "MM-dd-yyyy-hh-mm-ss")
	$esxiHashKey | ConvertTo-Json | Out-File "$ReportPath\$fileName.json"
	#Install-Prerequisites
	Generate-Report $esxiHashKey $jsonName $RegulatoryStandard $ReportPath
	Write-Verbose ""
	#if($auditAllFlag -eq 0){
		#Write-Output "Audit of $noOfEsxiConfigurations configurations of ESXi is done and report can be found at : $ReportPath\$fileName.json and $ReportPath\$fileName.xlsx"
		$esxiAuditDetails["jsonReportName"] = $fileName+".json"
		$esxiAuditDetails["excelReportName"] = $fileName+".xlsx"
		$esxiAuditDetails["reportPath"] = $ReportPath
		$esxiAuditDetails["noOfEsxiConfigurationsAudited"] = $noOfEsxiConfigurations
		
	#}
	return $esxiAuditDetails
	
}