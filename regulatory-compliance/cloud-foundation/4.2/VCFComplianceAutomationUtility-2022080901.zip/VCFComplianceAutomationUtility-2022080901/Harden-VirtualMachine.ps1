Function Harden-VirtualMachine
{
	<#

	.SYNOPSIS
	Hardens virtual machines in VCF Environment.

	.DESCRIPTION
	This Cmdlet is used to harden virtual machines based on the regulatory standard and domain of interest.
	The regulatory standards supported are  NIST, PCI and DISA.
	More support will be added in the future.
	
	.EXAMPLE
	Harden-VirtualMachine -RegulatoryStandard NIST -DomainName <Domain Name> -ReportPath <Path where reports are saved and logs to be saved>
	Harden-VirtualMachine -RegulatoryStandard PCI -DomainName <Domain Name> -ReportPath <Path where reports are saved and logs to be saved>
	Harden-VirtualMachine -RegulatoryStandard DISA -DomainName <Domain Name> -ReportPath <Path where reports are saved and logs to be saved>

	.NOTES
	Connect to VCF Server using Connect-VCFServer before running Harden-VirtualMachine Cmdlet.
	Run audit before hardening virtual machines.
	
	#>
	
	Param(
		[ValidateSet("DISA","PCI","NIST",IgnoreCase=$true)]
		[Parameter(mandatory=$true)]
        [String]$RegulatoryStandard,
		[Parameter(mandatory=$true)]
        [String]$DomainName,
		[Parameter(mandatory=$true)]
        [String]$ReportPath
	)
	
	$domainName = $DomainName.trim()
	$vmHardeningDetails = @{}
	if($vcfSession.Session -eq 0){
		Throw "You are not currently connected to SDDC Manager. Please connect using Connect-VCFServer cmdlet."
	}
	
	
	$fileNames = Get-ChildItem -Path $ReportPath
	if($fileNames.Name -Match $RegulatoryStandard+"_"+$domainName+"_"+"VirtualMachine"){
		
		$configFileName = $RegulatoryStandard.toLower()+"Config.json"
		$filePath = Join-Path -Path $PSScriptRoot -ChildPath $configFileName
		$configData = (Get-Content -Path $filePath -Raw )  | ConvertFrom-Json
		
		#$inputFileName = "inputSpec.json"
		#$inputFilePath = Join-Path -Path $PSScriptRoot -ChildPath $inputFileName
		#$inputSpecData = (Get-Content -Path $inputFilePath -Raw )  | ConvertFrom-Json
		
		$vcfCredentials = Select-Domain $domainName
		
		$product = "vCenter"
		
		$totalNoOfVMConfigurations = 0
		if($domain -eq "All"){
			Write-Progress " Remediating Virtual Machines of $domainName the Workload Domains:"
		}
		else{
			Write-Progress " Remediating Virtual Machines of $domainName Workload Domain: $domainName"
		}				   
		<#$AdvancedSettingsTrue =("isolation.tools.copy.disable","isolation.tools.dnd.disable","isolation.tools.paste.disable","isolation.tools.diskShrink.disable","isolation.tools.diskWiper.disable","isolation.tools.hgfsServerSet.disable","isolation.device.connectable.disable"#"tools.guest.desktop.autolock"
		)#>
		$AdvancedSettingsTrue =("VI-VC-AUD-00070","VI-VC-AUD-00071","VI-VC-AUD-00073","VI-VC-AUD-00074","VI-VC-AUD-00075","VI-VC-AUD-00076","VI-VC-AUD-00101")#"tools.guest.desktop.autolock"
		
		#$AdvancedSettingsFalse = ("RemoteDisplay.vnc.enabled","tools.guestlib.enableHostInfo","mks.enable3d")#"pciPassthru*.present"
		
		$AdvancedSettingsFalse = ("VI-VC-AUD-00097","VI-VC-AUD-00102","VI-VC-AUD-01233")#"pciPassthru*.present"
		
		$toHarden = Read-Host -Prompt "This Operation will make Configurational changes on your Virtual Machines - Do you want to proceed - Yes/No?"
		if($toHarden -like "y*" ){
			Foreach($vc in $vcfCredentials["vCenterList"].fqdn)
			{
				$logName = $RegulatoryStandard.toUpper() + "_hardenVirtualMachine"
				Connect-viserver -Server $vc -username $vcfCredentials["vcusername"] -password $vcfCredentials["vcpassword"] >> $ReportPath\\$logName.log
				$VMS = Get-VM | Where-Object {$_.Name -notlike "*vCLS*"}
				Foreach ($vm in $VMs){
					$noOfVMConfigurations = 0
					Write-Progress "Remediating $vm..."
					
					Foreach ($label in $AdvancedSettingsTrue) {
						$setting = Get-VM $vm | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Select-Object -Property Name, Value
						if(!$setting.Name){
							Get-VM $vm | New-AdvancedSetting -Name $configData.$product.$label.ParameterName -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
							$noOfVMConfigurations++
						}
						elseif($setting.Value -ne $true){
							Get-VM $vm | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
							$noOfVMConfigurations++
						}	
					}
					Foreach ($label in $AdvancedSettingsFalse) {
						$setting = Get-VM $vm | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Select-Object -Property Name, Value
						if(!$setting.Name){
							Get-VM $vm | New-AdvancedSetting -Name $configData.$product.$label.ParameterName -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
							$noOfVMConfigurations++
						}
						elseif($setting.Value -ne $false){
							Get-VM $vm | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
							$noOfVMConfigurations++
						}
					}
					
					$label = "VI-VC-AUD-00099"
					$advancedSetting = $configData.$product.$label.ParameterName
					$setting = Get-VM $vm | Get-AdvancedSetting -Name $advancedSetting | Select-Object -Property Name, Value
					if(!$setting.Name){
						Get-VM $vm | New-AdvancedSetting -Name $advancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
						$noOfVMConfigurations++
					}
					elseif($setting.Value -ne $configData.$product.$label.DesiredValue){
						Get-VM $vm | Get-AdvancedSetting -Name $advancedSetting | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
						$noOfVMConfigurations++
					}
					
					
					$label = "VI-VC-AUD-01242"
					$advancedSetting = $configData.$product.$label.ParameterName
					$setting = Get-VM $vm | Get-AdvancedSetting -Name $advancedSetting | Select-Object -Property Name, Value
					if(!$setting.Name){
						Get-VM $vm | New-AdvancedSetting -Name $advancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
						$noOfVMConfigurations++
					}
					elseif($setting.Value -ne $configData.$product.$label.DesiredValue){
						Get-VM $vm | Get-AdvancedSetting -Name $advancedSetting | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
						$noOfVMConfigurations++
					}
					
					$label = "VI-VC-AUD-00068"
					$advancedSetting = $configData.$product.$label.ParameterName
					$setting = Get-VM $vm | Get-AdvancedSetting -Name $advancedSetting
					if($setting){
						Get-VM $vm | Get-AdvancedSetting -Name $advancedSetting | Remove-AdvancedSetting -Confirm:$false >> $ReportPath\$logName.log
						$noOfVMConfigurations++
					}
						
					$label = "VI-VC-AUD-00096"	
					$advancedSetting = $configData.$product.$label.ParameterName
					$setting = Get-VM $vm | Get-AdvancedSetting -Name $advancedSetting | Select-Object -Property Name, Value
					if(!$setting.Name){
						Get-VM $vm | New-AdvancedSetting -Name $advancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
						$noOfVMConfigurations++
					}
					elseif($setting.Name -and $setting.Value -ne $configData.$product.$label.DesiredValue){
						Get-VM $vm | Get-AdvancedSetting -Name $advancedSetting | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
						$noOfVMConfigurations++
					}
						
					
					$label = "VI-VC-AUD-00154"
					$setting = Get-VM $vm | Get-HardDisk
					Foreach ($persistence in $setting.Persistence){
						if ($persistence -ne $configData.$product.$label.DesiredValue)
						{
							$flag = 1
							break
						}
					}
					if($flag -eq 1){
						Get-VM $vm | Get-HardDisk | Set-HardDisk -Persistence $configData.$product.$label.DesiredValue -Confirm:$false
						$noOfVMConfigurations++
					}
					
					$label = "VI-VC-AUD-00067"
					$setting = Get-VM $vm | Get-UsbDevice
					if($setting){
						Get-VM $vm | Get-USBDevice | Remove-USBDevice
						$noOfVMConfigurations++
					}
					
					$label = "VI-VC-AUD-00155"
					$setting = Get-VM $vm | Get-FloppyDrive | Select-Object ConnectionState
					$splittedValues = $setting.ConnectionState -split ","
					$value = $splittedValues[0]
					if($value -eq "Connected"){
						Get-VM $vm | Get-FloppyDrive | Remove-FloppyDrive -Confirm:$false
						$noOfVMConfigurations++
					}
					
					$label = "VI-VC-AUD-00156"
					$drive = Get-VM $vm | Get-CDDrive
					$setting = $drive.extensiondata.connectable.connected
					if($setting -eq "True"){
						Get-VM $vm | Get-CDDrive | Set-CDDrive -NoMedia -Confirm:$false
						$noOfVMConfigurations++
					}
					
					$label = "VI-VC-AUD-01232"		
					if($vm.ExtensionData.Guest.GustFullName -Like "*Windows*"){
						$setting = Get-VM $vm | Get-AdvancedSetting -Name tools.guest.desktop.autolock
						$noOfVMConfigurations++
						if(!$setting.Name){
							Get-VM $vm | New-AdvancedSetting -Name $advancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
							$noOfVMConfigurations++
						}
						elseif($setting.Value -ne $true){
							Get-VM $vm | Get-AdvancedSetting -Name $advancedSetting | Set-AdvancedSetting -Value $configData.$product.$label.DesiredValue -Confirm:$false >> $ReportPath\$logName.log
							$noOfVMConfigurations++
						}
					}	
					
					$label = "VI-VC-AUD-00561"
					$setting = Get-VM $vm | Get-AdvancedSetting -Name "pciPassthru*.present"
					if($setting){
						Get-VM $vm | Get-AdvancedSetting -Name "pciPassthru*.present" | Remove-AdvancedSetting -Confirm:$false
						$noOfVMConfigurations++
					}
					Write-Verbose "$noOfVMConfigurations configurations on $vm got remediated"
					
				}	
				
				$totalNoOfVMConfigurations += $noOfVMConfigurations	
				disconnect-viserver -Server $vc -Confirm:$false
			}
			
			if($totalNoOfVMConfigurations -gt 0){
				$remediationMessage = "Please re-run Audit-VirtualMachine to check the status after Hardening"
			}
			else{
				$remediationMessage = "None of the Configurations got remediated"
			}
		}
		elseif($toHarden -like "n*"){
			$remediationMessage = "You must harden your Virtual Machines to be compliant with $RegulatoryStandard"
		}
		else{
			throw "Invalid Input. Please try again."
		}
		$vmHardeningDetails["TotalNoOfVmConfigurationsRemediated"] = $totalNoOfVMConfigurations
		$vmHardeningDetails["RemediationMessage"] = $remediationMessage
		return $vmHardeningDetails
	}
	else{
		Throw "Please run Audit-VirtualMachine with RegulatorStandard : $RegulatoryStandard and DomainName : $domainName before hardening"
	}
	
	
}