Function Harden-SDDCManager
{
	<#

	.SYNOPSIS
	Hardens SDDC Manager.

	.DESCRIPTION
	This Cmdlet is used to harden SDDC Manager based on the regulatory standard.
	The regulatory standards supported are  NIST, PCI and DISA.
	More support will be added in the future.
	
	.EXAMPLE
	Harden-SDDCManager -RegulatoryStandard NIST -ReportPath <Path where reports are saved and logs to be saved>
	Harden-SDDCManager -RegulatoryStandard PCI -ReportPath <Path where reports are saved and logs to be saved>
	Harden-SDDCManager -RegulatoryStandard DISA -ReportPath <Path where reports are saved and logs to be saved>

	.NOTES
	Run audit before hardening SDDC Manager.
	
	#>
	
	Param(
		[ValidateSet("DISA","PCI","NIST",IgnoreCase=$true)]
		[Parameter(mandatory=$true)]
        [String]$RegulatoryStandard,
		[Parameter(mandatory=$true)]
        [String]$ReportPath
	)
	
	#$domainName = $DomainName.trim()
	$sddcHardeningDetails = @{}
	if($vcfSession.Session -eq 0){
		Throw "You are not currently connected to SDDC Manager. Please connect using Connect-VCFServer cmdlet."
	}
	
	$fileNames = Get-ChildItem -Path $ReportPath
	if($fileNames.Name -Match $RegulatoryStandard+"_"+"SDDC"){
		
		<#$configFileName = $RegulatoryStandard.toLower()+"Config.json"
		$filePath = Join-Path -Path $PSScriptRoot -ChildPath $configFileName
		$configData = (Get-Content -Path $filePath -Raw )  | ConvertFrom-Json
		
		$inputFileName = "inputSpec.json"
		$inputFilePath = Join-Path -Path $PSScriptRoot -ChildPath $inputFileName
		$inputSpecData = (Get-Content -Path $inputFilePath -Raw )  | ConvertFrom-Json
		#>
		
		$noOfSDDCConfigurations = 0
		$sddcServer = $vcfSession.SddcServer
		#$logName = $RegulatoryStandard.toUpper() + "_hardenSDDC"
		
		$toHarden = Read-Host -Prompt "This Operation will make Configurational changes on your SDDC Manager - Do you want to proceed - Yes/No?"
		if($toHarden -like "y*" )
		{
		
			$headers = generateAccessToken $sddcServer $vcfSession.SddcUsername $vcfSession.SecretPassword

			
			#ControlID = CFAP-4X-000007
			#$label = "VI-SDDC-AUD-1606"
			#$confLabel = "$RegulatoryStandard-$label"
			$uri = "https://$sddcServer/v1/system/ceip"

			$ceipConfig = GetSDDCManagerAPIMethod $uri $headers
			
			if($ceipConfig.status -ne "DISABLED"){
				$noOfSDDCConfigurations++
				$body = @{
					status = "DISABLE"
				} | ConvertTo-Json
				$ceipParams = @{
						uri = "https://$sddcServer/v1/system/ceip"
						Headers = $headers
						ContentType = "application/json"
						Method = "PATCH"
						Body = $body
				}

				if($PSVersionTable.PSEdition -eq "Desktop"){
					$ceipConfig = try {
						Invoke-RestMethod @ceipParams
					} 
					catch{
						$_.Exception.Response
					}
				}
				else{
					$ceipConfig = try {
						Invoke-RestMethod @ceipParams -SkipCertificateCheck
					} 
					catch{
						$_.Exception.Response
					}
				}
			}
			
			if($noOfSDDCConfigurations -gt 0){
				$remediationMessage = "Please re-run Audit-SDDCManager to check the status after Hardening"
			}
			else{
				$remediationMessage = "None of the Configurations got remediated"
			}
		}
		elseif($toHarden -like "n*"){
			$remediationMessage = "You must harden your SDDC Manager to be compliant with $RegulatoryStandard"
		}
		else{
			throw "Invalid Input. Please try again."
		}
		$sddcHardeningDetails["TotalNoOfSddcConfigurationsRemediated"] = $noOfSDDCConfigurations
		$sddcHardeningDetails["RemediationMessage"] = $remediationMessage 
		return $sddcHardeningDetails
	}
	else{
		Throw "Please run Audit-SDDCManager with RegulatorStandard : $RegulatoryStandard before hardening"
	}
	
}