Function Audit-VirtualMachine
{	
	<#

	.SYNOPSIS
	Audits virtual machines in VCF Environment.

	.DESCRIPTION
	This Cmdlet is used to audit virtual machines based on the regulatory standard and domain of interest.
	The regulatory standards supported are  NIST, PCI and DISA.
	More support will be added in the future.
	
	.EXAMPLE
	Audit-VirtualMachine -RegulatoryStandard NIST -DomainName <Domain Name> -ReportPath <Path where reports and logs get saved>
	Audit-VirtualMachine -RegulatoryStandard PCI -DomainName <Domain Name> -ReportPath <Path where reports and logs get saved>
	Audit-VirtualMachine -RegulatoryStandard DISA -DomainName <Domain Name> -ReportPath <Path where reports and logs get saved>

	.NOTES
	Connect to VCF Server using Connect-VCFServer before running Audit-VirtualMachine Cmdlet.
	
	#>
	
	Param(
		[ValidateSet("DISA","PCI","NIST",IgnoreCase=$true)]
		[Parameter(mandatory=$true)]
        [String]$RegulatoryStandard,
		[Parameter(mandatory=$true)]
        [String]$DomainName,
		[Parameter(mandatory=$true)]
		[ValidateScript({Test-Path $_})]
        [String]$ReportPath
	)
	
	$domainName = $DomainName.trim()
	$vmAuditDetails = @{}
	$compliant="Pass"
	$nonCompliant="Fail"
	
	if($vcfSession.Session -eq 0){
		Throw "You are not currently connected to SDDC Manager. Please connect using Connect-VCFServer cmdlet."
	}
	
	$configFileName = $RegulatoryStandard.toLower()+"Config.json"
	$filePath = Join-Path -Path $PSScriptRoot -ChildPath $configFileName
	$configData = (Get-Content -Path $filePath -Raw )  | ConvertFrom-Json
	
	<#$inputFileName = "inputSpec.json"
	$inputFilePath = Join-Path -Path $PSScriptRoot -ChildPath $inputFileName
	$inputSpecData = (Get-Content -Path $inputFilePath -Raw )  | ConvertFrom-Json
	#>
	$jsonName = $RegulatoryStandard.toUpper() + "_" + $domainName + "_VirtualMachine"
	$product = "vCenter"
	
	
	$vcfCredentials = Select-Domain $domainName

	
	if($domainName -eq "All"){
			Write-Progress " Auditing Virtual Machines of $domainName the Workload Domain:"
	}
	else{
		Write-Progress " Auditing Virtual Machines of $domainName Workload Domain: "
	}
	
	$vmHashKey = @{}
	
	$AdvancedSettingsTrue =("VI-VC-AUD-00070",
	"VI-VC-AUD-00071",
	"VI-VC-AUD-00073",
	"VI-VC-AUD-00074",
	"VI-VC-AUD-00075",
	"VI-VC-AUD-00076",
	"VI-VC-AUD-00101"
	)
	$AdvancedSettingsFalse=("VI-VC-AUD-00097",
	"VI-VC-AUD-00102",
	"VI-VC-AUD-01233")
	Foreach($vc in $vcfCredentials["vCenterList"].fqdn){
		
		$logName = $RegulatoryStandard + "_auditVirtualMachine"
		$connection = Connect-viserver -Server $vc -username $vcfCredentials["vcusername"] -password $vcfCredentials["vcpassword"] -ErrorAction SilentlyContinue
		if($connection)
		{
			$VMS = Get-VM | Where-Object {$_.Name -notlike "*vCLS*"}
			if($VMs){
				Foreach ($vm in $VMs){
					Write-Progress "*********   Auditing $vm ...   *********"
					$noOfVMConfigurations = 0
					$vmHashInnerKey = @{}
					
					Foreach ($label in $AdvancedSettingsTrue) {
						$confLabel = "$RegulatoryStandard-$label"
						$setting = Get-VM $vm | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Select-Object -Property Name, Value
						$noOfVMConfigurations++
						if(($setting.Name) -AND ($setting.Value -eq $true)){
							$complianceState = $compliant
						}
						else
						{
							$complianceState = $nonCompliant
						}
						$currentValue = $setting.Value
						if($RegulatoryStandard -eq "DISA"){
							$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
						}
						else{
							$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
						}
					}
				
					Foreach ($label in $AdvancedSettingsFalse) {
						$confLabel = "$RegulatoryStandard-$label"
						$setting = Get-VM $vm | Get-AdvancedSetting -Name $configData.$product.$label.ParameterName | Select-Object -Property Name, Value
						$noOfVMConfigurations++
						if(($setting.Name) -AND ($setting.Value -eq $false)){
							$complianceState = $compliant
						}
						else
						{
							$complianceState = $nonCompliant
						}
						
						$currentValue = $setting.Value
						if($RegulatoryStandard -eq "DISA"){
							$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
						}
						else{
							$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
						}
					}	
					
					$label = "VI-VC-AUD-01232"
					$confLabel = "$RegulatoryStandard-$label"
					
					if($vm.ExtensionData.Guest.GustFullName -Like "*Windows*"){
						$setting = Get-VM $vm | Get-AdvancedSetting -Name tools.guest.desktop.autolock
						$noOfVMConfigurations++
						if(($setting.Name) -AND ($setting.Value -eq $true)){
							$complianceState = $compliant
						}
						else
						{
							$complianceState = $nonCompliant
						}
						$currentValue = $setting.Value
						if($RegulatoryStandard -eq "DISA"){
							$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
						}
						else{
							$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
						}	
					}
					else{
						$complianceState = "Not Applicable"
						$noOfVMConfigurations++
						$currentValue = "VM is not Windows-based"
						if($RegulatoryStandard -eq "DISA"){
							$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
						}
						else{
							$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
						}
					}
				
					<#$label = "VI-VC-AUD-00561"
					$confLabel = "$RegulatoryStandard-$label"
					
					$noOfVMConfigurations++
					$setting = Get-VM $vm | Get-AdvancedSetting -Name "pciPassthru*.present"
					if(!$setting){
						$complianceState = $compliant
					}
					else {
						$complianceState = $nonCompliant
					} 
					$currentValue = $setting.Value
					if($RegulatoryStandard -eq "DISA"){
						$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					#>

					$label = "VI-VC-AUD-00065"
					$confLabel = "$RegulatoryStandard-$label"
					
					$noOfVMConfigurations++
					$setting = Get-VM $vm | Where-Object {$_.ExtensionData.Config.Hardware.Device.DeviceInfo.Label -match "parallel"}
					if(!$setting){
						$complianceState = $compliant
						$currentValue = "No Parallel devices connected"
					}
					else {
						$complianceState = $nonCompliant
						$currentValue = "Parallel devices connected"
					} 
					if($RegulatoryStandard -eq "DISA"){
						$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					
					$label = "VI-VC-AUD-00066"
					$confLabel = "$RegulatoryStandard-$label"
					
					$noOfVMConfigurations++
					$setting = Get-VM $vm | Where-Object {$_.ExtensionData.Config.Hardware.Device.DeviceInfo.Label -match "serial"}
					if(!$setting){
						$complianceState = $compliant
						$currentValue = "No Serial devices connected"
					}
					else {
						$complianceState = $nonCompliant
						$currentValue = "Serial devices connected"
					} 
					
					if($RegulatoryStandard -eq "DISA"){
						$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					
					$label = "VI-VC-AUD-00067"
					$confLabel = "$RegulatoryStandard-$label"
					
					$noOfVMConfigurations++
					$setting = Get-VM $vm | Get-UsbDevice
					if(!$setting){
						$complianceState = $compliant
						$currentValue = "No USB devices connected"
					}
					else {
						$complianceState = $nonCompliant
						$currentValue = "USB devices connected"
					} 
					if($RegulatoryStandard -eq "DISA"){
						$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-VC-AUD-00068"
					$confLabel = "$RegulatoryStandard-$label"
					
					$noOfVMConfigurations++
					$setting = Get-VM $vm | Get-AdvancedSetting -Name sched.mem.pshare.salt
					if(!$setting){
						$complianceState = $compliant
						$currentValue = "Advanced setting not configured"
					}
					else {
						$complianceState = $nonCompliant
						$currentValue = "Advanced setting configured"
					} 
					
					
					if($RegulatoryStandard -eq "DISA"){
						$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$flag=0
					$label = "VI-VC-AUD-00096"
					$confLabel = "$RegulatoryStandard-$label"
					
					$noOfVMConfigurations++
					$setting = Get-VM $vm | Get-AdvancedSetting -Name RemoteDisplay.maxConnections | Select-Object -Property Name, Value
					if((!$setting.Name) -or ($setting.Name -and $setting.Value -ne 1)){
						$flag = 1
					}
				
					if ($flag -eq 0)
					{
						$complianceState = $compliant
					}
					else {
						$complianceState = $nonCompliant
					} 
					$currentValue = $setting.Value
					if($RegulatoryStandard -eq "DISA"){
						$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$flag=0
					$label = "VI-VC-AUD-00099"
					$confLabel = "$RegulatoryStandard-$label"
					
					$noOfVMConfigurations++
					$setting = Get-VM $vm | Get-AdvancedSetting -Name tools.setinfo.sizeLimit | Select-Object -Property Name, Value
					if((!$setting.Name) -or ($setting.Value -ne 1048576)){
						$flag = 1
					}
				
					if ($flag -eq 0)
					{
						$complianceState = $compliant
					}
					else {
						$complianceState = $nonCompliant
					} 
					$currentValue = $setting.Value
					if($RegulatoryStandard -eq "DISA"){
						$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$flag=0
					$label = "VI-VC-AUD-00154"
					$confLabel = "$RegulatoryStandard-$label"
					
					$noOfVMConfigurations++
					$setting = Get-VM $vm | Get-HardDisk
					Foreach ($persistence in $setting.Persistence){
						if ($persistence -ne "Persistent")
						{
							$currentValue = $persistence
							$flag = 1
							break
						}
					}
					
					if ($flag -eq 0)
					{
						$complianceState = $compliant
						$currentValue = "Persistent"
						
					}
					else {
						$complianceState = $nonCompliant
					} 
					
					if($RegulatoryStandard -eq "DISA"){
						$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$flag=0
					$label = "VI-VC-AUD-00155"
					$confLabel = "$RegulatoryStandard-$label"
					
					$noOfVMConfigurations++
					$setting = Get-VM $vm | Get-FloppyDrive | Select-Object ConnectionState
					$splittedValues = $setting.ConnectionState -split ","
					$value = $splittedValues[0]
					if($value -eq "Connected"){
						$flag = 1
					}
					
					if ($flag -eq 0)
					{
						$complianceState = $compliant
						$currentValue = "No Floppy devices connected"
					}
					else {
						$complianceState = $nonCompliant
						$currentValue = "Floppy devices connected"
					} 
					
					if($RegulatoryStandard -eq "DISA"){
						$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}

					$flag=0
					$label = "VI-VC-AUD-00156"
					$confLabel = "$RegulatoryStandard-$label"
					
					$noOfVMConfigurations++
					$drive = Get-VM $vm | Get-CDDrive
					$setting = $drive.extensiondata.connectable.connected
					if($setting -eq "True"){
						$flag = 1
					}

					if ($flag -eq 0)
					{
						$complianceState = $compliant
						$currentValue = "No CD/DVD devices connected"
					}
					else {
						$complianceState = $nonCompliant
						$currentValue = "CD/DVD devices connected"
					} 
					
					if($RegulatoryStandard -eq "DISA"){
						$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$label = "VI-VC-AUD-01234"
					$confLabel = "$RegulatoryStandard-$label"
					
					$noOfVMConfigurations++
					$setting = $vm.ExtensionData.Config.MigrateEncryption
					
					if($setting -eq "opportunistic" -or $setting -eq "required"){
						$complianceState = $compliant
					}
					else {
						$complianceState = $nonCompliant
					} 
					$currentValue = $setting
					if($RegulatoryStandard -eq "DISA"){
						$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					
					<#$label = "VI-VC-AUD-01215"
					$confLabel = "$RegulatoryStandard-$label"
					
					$noOfVMConfigurations++
					$setting = Get-VM $vm | Get-AdvancedSetting -Name "ethernet*.filter*.name*"
					
					if(!$setting){
						$complianceState = $compliant
					}
					else {
						$complianceState = $nonCompliant
					} 
					$currentValue = $setting
					if($RegulatoryStandard -eq "DISA"){
						$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					#>
					
					$flag=0
					$label = "VI-VC-AUD-01243"
					$confLabel = "$RegulatoryStandard-$label"
					
					$setting = Get-VM $vm | Get-AdvancedSetting -Name log.keepOld | Select-Object -Property Name, Value
					
					if($setting){
						$currentValue = $setting.Value
						$noOfVMConfigurations++
						if($setting.Value -ne 10){
							$complianceState = $nonCompliant
						}
						else{
							$complianceState = $compliant
						}
						if($RegulatoryStandard -eq "DISA"){
							$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
						}
						else{
							$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
						}	
					}
					else{
						$complianceState = "Not Applicable"
						$noOfVMConfigurations++
						$currentValue = "Advanced Setting not Configured"
						if($RegulatoryStandard -eq "DISA"){
							$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
						}
						else{
							$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
						}
					}
					
					
					$flag=0
					$label = "VI-VC-AUD-01242"
					$confLabel = "$RegulatoryStandard-$label"
					
					$noOfVMConfigurations++
					$setting = Get-VM $vm | Get-AdvancedSetting -Name log.rotateSize | Select-Object -Property Name, Value
					if((!$setting.Name) -or ($setting.Value -ne 2048000)){
						$flag = 1
					}
				
					if ($flag -eq 0)
					{
						$complianceState = $compliant
					}
					else {
						$complianceState = $nonCompliant
					} 
					$currentValue = $setting.Value
					if($RegulatoryStandard -eq "DISA"){
						$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					$flag=0
					$label = "VI-VC-AUD-01241"
					$confLabel = "$RegulatoryStandard-$label"
					
					$noOfVMConfigurations++
					$setting = Get-VM $vm | Where-Object {$_.ExtensionData.Config.Flags.EnableLogging -ne "True"}
					if($setting){
						$flag = 1
					}
					if ($flag -eq 0)
					{
						$complianceState = $compliant
						$currentValue = "Logging is enabled"
					}
					else {
						$complianceState = $nonCompliant
						$currentValue = "Logging is not enabled"
					} 
					
					if($RegulatoryStandard -eq "DISA"){
						$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					else{
						$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
					}
					
					
					$label = "VI-VC-AUD-01244"
					$confLabel = "$RegulatoryStandard-$label"
					$ftConfig = $vm.ExtensionData.Config.FtInfo
					if($ftConfig){
						$noOfVMConfigurations++
						if($vm.ExtensionData.Config.FtEncryptionMode -eq "ftEncryptionOpportunistic" -or $vm.ExtensionData.Config.FtEncryptionMode -eq "ftEncryptionRequired"){
							$complianceState = $compliant
						}
						else {
							$complianceState = $nonCompliant
						}
						$currentValue = $vm.ExtensionData.Config.FtEncryptionMode
						if($RegulatoryStandard -eq "DISA"){
							$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
						}
						else{
							$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
						}	
					}
					else{
						$complianceState = "Not Applicable"
						$noOfVMConfigurations++
						$currentValue = "Fault Tolerance is not configured"
						if($RegulatoryStandard -eq "DISA"){
							$vmHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
						}
						else{
							$vmHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
						}
					}
					
					
					
					$vmHashKey[$vm.name] = $vmHashInnerKey	
				}
			}
			else{
				Write-Verbose "No Virtual Machines to Audit."
			}
			disconnect-viserver -Server $vc -Confirm:$false
		}
		else
		{
			$logMessage = "Resolve connectivity issue of $vc and run the audit again." 
			$logMessage >> $ReportPath\\$logName.log
		}
	}
	$fileName = $jsonName +"_"+ (Get-Date -Format "dd-MM-yyyy-hh-mm-ss")
	$vmHashKey | ConvertTo-Json | Out-File "$ReportPath\$fileName.json"
	Generate-Report $vmHashKey $jsonName $RegulatoryStandard $ReportPath
	<#Write-Verbose ""
	if($auditAllFlag -eq 0){
		Write-Output "Audit of $noOfVMConfigurations Configurations of VM is done and report can be found at : $ReportPath\$fileName.json and $ReportPath\$fileName.xlsx"
	}#>
	
	$vmAuditDetails["jsonReportName"] = $fileName+".json"
	$vmAuditDetails["excelReportName"] = $fileName+".xlsx"
	$vmAuditDetails["reportPath"] = $ReportPath
	$vmAuditDetails["noOfVmConfigurationsAudited"] = $noOfVMConfigurations
		
		
	return $vmAuditDetails
}