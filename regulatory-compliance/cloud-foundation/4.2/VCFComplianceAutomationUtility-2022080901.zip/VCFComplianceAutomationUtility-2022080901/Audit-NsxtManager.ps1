Function Audit-NsxtManager
{
	<#

	.SYNOPSIS
	Audits NSXT Manager in VCF Environment.

	.DESCRIPTION
	This Cmdlet is used to audit NSXT Managers based on the regulatory standard and domain of interest.
	The regulatory standards supported are  NIST, PCI and DISA.
	More support will be added in the future.
	
	.EXAMPLE
	Audit-NsxtManager -RegulatoryStandard NIST -DomainName <Domain Name> -ReportPath <Path where reports and logs get saved>
	Audit-NsxtManager -RegulatoryStandard PCI -DomainName <Domain Name> -ReportPath <Path where reports and logs get saved>
	Audit-NsxtManager -RegulatoryStandard DISA -DomainName <Domain Name> -ReportPath <Path where reports and logs get saved>

	.NOTES
	Connect to VCF Server using Connect-VCFServer before running Audit-NsxtManager Cmdlet.
	
	#>
	
	Param(
		[ValidateSet("DISA","PCI","NIST",IgnoreCase=$true)]
		[Parameter(mandatory=$true)]
        [String]$RegulatoryStandard,
		[Parameter(mandatory=$true)]
        [String]$DomainName,
		[Parameter(mandatory=$true)]
		[ValidateScript({Test-Path $_})]
        [String]$ReportPath
	)
	
	$domainName = $DomainName.trim()
	$nsxtAuditDetails = @{}
	$compliant="Pass"
	$nonCompliant="Fail"
	
	if($vcfSession.Session -eq 0){
		Throw "You are not currently connected to SDDC Manager. Please connect using Connect-VCFServer cmdlet."
	}
	
	$configFileName = $RegulatoryStandard.toLower()+"Config.json"
	$filePath = Join-Path -Path $PSScriptRoot -ChildPath $configFileName
	$configData = (Get-Content -Path $filePath -Raw )  | ConvertFrom-Json
	
	$inputFileName = "inputSpec.json"
	$inputFilePath = Join-Path -Path $PSScriptRoot -ChildPath $inputFileName
	$inputSpecData = (Get-Content -Path $inputFilePath -Raw )  | ConvertFrom-Json
	
	$jsonName = $RegulatoryStandard.toUpper() + "_" + $domainName + "_NSXT"
	$product = "NSX-T"
	
	
	$vcfCredentials = Select-Domain $domainName
	

	if($domainName -eq "All"){
			Write-Output "This will take a little longer time."
			Write-Progress " Auditing NSX-T Managers of $domainName Workload Domains...:"
	}
	else{
		Write-Output "This will take a little longer time."
		Write-Progress " Auditing NSX-T Managers of $domainName Workload Domain: "
	}
	
	$nsxtHashKey = @{}
	Start-Sleep -Seconds 120
	Foreach($nsxt in $vcfCredentials["nsxtNodesList"].fqdn)
	{
		$nsxtHashInnerKey = @{}
		$noOfNSXTConfigurations = 0
		
		if($domainName -eq "All"){
			$nsxtCredentials = Get-VCFCredential | Where-Object {$_.credentialType -eq "API" -and $_.resource.resourceType -eq "NSXT_MANAGER" -and $_.resource.resourceId -eq $vcfCredentials["nsxtClusterNodesList"][$nsxt]} | Select-Object username, password
			$username = $nsxtCredentials.userName
			$password = $nsxtCredentials.password
			
		}	
		else{
			$username = $vcfCredentials["nsxtUsername"].username
			$password = $vcfCredentials["nsxtPassword"].password
		}
		
		$logName = $RegulatoryStandard.toUpper() + "_auditNSXT"
		Write-Progress "*********   Auditing $nsxt ...   *********"
		$connection = Connect-NsxtServer -Server $nsxt -User $username -Password $password -ErrorAction SilentlyContinue
		#$connection = 0
		if($connection)
		{
			$label = "VI-NET-AUD-01422"
			$confLabel = "$RegulatoryStandard-$label"
			
			$clusterConfig = Get-NsxtService -Name "com.vmware.nsx.cluster.status"
			$clusterStatus = $clusterConfig.get().mgmt_cluster_status.status
			$nodes = $clusterConfig.get().mgmt_cluster_status.online_nodes
			$clusterIp = Get-NsxtService -Name "com.vmware.nsx.cluster.api_virtual_ip"
			$virtualIp = $clusterIp.get().ip_address
			$clusterNodes = $nodes.mgmt_cluster_listen_ip_address
			$nodeCount = 0
			foreach($node in $clusterNodes){
				$nodeCount++
			}
			
			if($nodeCount -eq 3 -AND $clusterStatus -eq "STABLE" -AND $virtualIp){
				$complianceState = $compliant
			}
			else {
				$complianceState = $nonCompliant
			}
			$noOfNSXTConfigurations++
			$currentValue = "nodeCount : " + $nodeCount + ", clusterStatus : " + $clusterStatus + ", virtualIp : " + $virtualIp

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			#TNDM-3X-000012
			$label = "VI-NET-AUD-01497"
			$confLabel = "$RegulatoryStandard-$label"
			
			$authPolicy = Get-NsxtService -Name com.vmware.nsx.node.aaa.auth_policy
			$cliLockoutPeriod = $authPolicy.get().cli_failed_auth_lockout_period
			
			if($cliLockoutPeriod -eq $configData.$product.$label.DesiredValue){
				$complianceState = $compliant
			}
			else {
				$complianceState = $nonCompliant
			} 
			$noOfNSXTConfigurations++
			$currentValue = $cliLockoutPeriod

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			#TNDM-3X-000012
			$label = "VI-NET-AUD-01498"
			$confLabel = "$RegulatoryStandard-$label"
			
			$cliMaxAuthFailures = $authPolicy.get().cli_max_auth_failures
			
			if($cliMaxAuthFailures -eq $configData.$product.$label.DesiredValue){
				$complianceState = $compliant
			}
			else {
				$complianceState = $nonCompliant
			} 
			$noOfNSXTConfigurations++
			$currentValue = $cliMaxAuthFailures

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			#TNDM-3X-000012
			$label = "VI-NET-AUD-01417"
			$confLabel = "$RegulatoryStandard-$label"
			
			$authPolicy = Get-NsxtService -Name com.vmware.nsx.node.aaa.auth_policy
			$apiLockoutPeriod = $authPolicy.get().api_failed_auth_lockout_period
			
			if($apiLockoutPeriod -eq $configData.$product.$label.DesiredValue){
				$complianceState = $compliant
			}
			else {
				$complianceState = $nonCompliant
			} 
			$noOfNSXTConfigurations++
			$currentValue = $apiLockoutPeriod

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			#TNDM-3X-000012
			$label = "VI-NET-AUD-01418"
			$confLabel = "$RegulatoryStandard-$label"
			
			$apiMaxAuthFailures = $authPolicy.get().api_max_auth_failures
			
			if($apiMaxAuthFailures -eq $configData.$product.$label.DesiredValue){
				$complianceState = $compliant
			}
			else {
				$complianceState = $nonCompliant
			} 
			$noOfNSXTConfigurations++
			$currentValue = $apiMaxAuthFailures

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			#TNDM-3X-000015
			$label = "VI-NET-AUD-01415"
			$confLabel = "$RegulatoryStandard-$label"
			
			$vidm = Get-NsxtService -Name com.vmware.nsx.node.aaa.providers.vidm
			$vidmConfig = $vidm.get().vidm_enable
			
			if($vidmConfig -eq $true){
				$complianceState = $compliant
			}
			else {
				$complianceState = $nonCompliant
			} 
			$noOfNSXTConfigurations++
			$currentValue = $vidmConfig

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			#TNDM-3X-000012
			$label = "VI-NET-AUD-01419"
			$confLabel = "$RegulatoryStandard-$label"
			
			$authPolicy = Get-NsxtService -Name com.vmware.nsx.node.aaa.auth_policy
			$apiLockoutResetPeriod = $authPolicy.get().api_failed_auth_reset_period
			
			if($apiLockoutResetPeriod -eq $configData.$product.$label.DesiredValue){
				$complianceState = $compliant
			}
			else {
				$complianceState = $nonCompliant
			} 
			$noOfNSXTConfigurations++
			$currentValue = $apiLockoutResetPeriod

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			#TNDM-3X-000041
			$label = "VI-NET-AUD-01421"
			$confLabel = "$RegulatoryStandard-$label"
			
			$authPolicy = Get-NsxtService -Name com.vmware.nsx.node.aaa.auth_policy
			$passwordLength = $authpolicy.get().minimum_password_length
			
			if($passwordLength -ge $configData.$product.$label.DesiredValue){
				$complianceState = $compliant
			}
			else {
				$complianceState = $nonCompliant
			} 
			$noOfNSXTConfigurations++
			$currentValue = $passwordLength

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			#TDFW-3X-000021
			$label = "VI-NET-AUD-01412"
			$confLabel = "$RegulatoryStandard-$label"
			
			$nsxtFirewallSectionIds = Get-NSXTFirewallSectionID
			$firewallRules = Get-NsxtService -Name "com.vmware.nsx.firewall.sections.rules"
			if($nsxtFirewallSectionIds["dfwId"]){
				$dfwRules = $firewallRules.list($nsxtFirewallSectionIds["dfwId"]).results
				foreach($dfwRule in $dfwRules){
					if($dfwRule.display_name -eq "Default Layer3 Rule"){
						$dfwAction = $dfwRule.action
					}
				}
				
				if($dfwAction -eq "allow"){
					$complianceState = $nonCompliant
				}
				else {
					$complianceState = $compliant
				}
				$noOfNSXTConfigurations++
				$currentValue = $dfwAction
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			else{
				$complianceState = "Not Applicable"
				$noOfNSXTConfigurations++
				$currentValue = "Resource not Configured"
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
				
			#TDFW-3X-000005
			$label = "VI-NET-AUD-01409"
			$confLabel = "$RegulatoryStandard-$label"
			$dfwFlag=0
			$dfwLogging=""
			if($nsxtFirewallSectionIds["dfwId"]){
				$dfwRules = $firewallRules.list($nsxtFirewallSectionIds["dfwId"]).results
				foreach($dfwRule in $dfwRules){
					if($dfwRule.logged -eq $false){
						$dfwFlag = 1
						$dfwLogging = "False"
						break
					}
					else{
						$dfwLogging = "True"
					}
				}
				
				if($dfwFlag -eq 0){
					$complianceState = $compliant
				}
				else {
					$complianceState = $nonCompliant
				}
				$noOfNSXTConfigurations++
				$currentValue = $dfwLogging
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			
			}
			else{
				$complianceState = "Not Applicable"
				$noOfNSXTConfigurations++
				$currentValue = "Resource not Configured"
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			
			#T0FW-3X-000021
			$label = "VI-NET-AUD-01432"
			$confLabel = "$RegulatoryStandard-$label"
			if($nsxtFirewallSectionIds["tier0Id"]){
				$t0GwRules = $firewallRules.list($nsxtFirewallSectionIds["tier0Id"]).results
				foreach($t0GwRule in $t0GwRules){
					if($t0GwRule.display_name -eq "default_rule"){
						$t0Action = $t0GwRule.action
					}
				}	
				if($t0Action -eq "allow"){
					$complianceState = $nonCompliant
				}
				else {
					$complianceState = $compliant
				} 
				$noOfNSXTConfigurations++
				$currentValue = $t0Action
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			else{
				$complianceState = "Not Applicable"
				$noOfNSXTConfigurations++
				$currentValue = "Resource not Configured"
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
				
			#T0FW-3X-000005
			$label = "VI-NET-AUD-01429"
			$confLabel = "$RegulatoryStandard-$label"
				
			$t0GwFlag = 0
			$t0GwLogging=""
			if($nsxtFirewallSectionIds["tier0Id"]){
				$t0GwRules = $firewallRules.list($nsxtFirewallSectionIds["tier0Id"]).results
				foreach($t0GwRule in $t0GwRules){
					if($t0GwRule.logged -eq $false){
						$t0GwFlag = 1
						$t0GwLogging = "False"
						break
					}
					else{
						$t0GwLogging = "True"
					}
				}	
				if($t0GwFlag -eq 0){
					$complianceState = $compliant
				}
				else {
					$complianceState = $nonCompliant
				}
				$noOfNSXTConfigurations++
				$currentValue = $t0GwLogging
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			else{
				$complianceState = "Not Applicable"
				$noOfNSXTConfigurations++
				$currentValue = "Resource not Configured"
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			#T1FW-3X-000021
			$label = "VI-NET-AUD-01431"
			$confLabel = "$RegulatoryStandard-$label"
			
			if($nsxtFirewallSectionIds["tier1Id"]){
				$t1GwRules = $firewallRules.list($nsxtFirewallSectionIds["tier1Id"]).results
				foreach($t1GwRule in $t1GwRules){
					if($t1GwRule.display_name -eq "default_rule"){
						$t1Action = $t1GwRule.action
					}
				}
				if($t1Action -eq "allow"){
					$complianceState = $nonCompliant
				}
				else {
					$complianceState = $compliant
				}
				$noOfNSXTConfigurations++
				$currentValue = $t1Action
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			else{
				$complianceState = "Not Applicable"
				$noOfNSXTConfigurations++
				$currentValue = "Resource not Configured"
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
				
			#T1FW-3X-000005
			$label = "VI-NET-AUD-01514"
			$confLabel = "$RegulatoryStandard-$label"
			if($nsxtFirewallSectionIds["tier1Id"]){
				$t1GwRules = $firewallRules.list($nsxtFirewallSectionIds["tier1Id"]).results	
				$t1GwFlag = 0
				$t1GwLogging=""
				foreach($t1GwRule in $t1GwRules){
					if($t1GwRule.logged -eq $false){
						$t1GwFlag = 1
						$t1GwLogging="False"
						break
					}
					else{
						$t1GwLogging="True"
					}
				}	
				if($t1GwFlag -eq 0){
					$complianceState = $compliant
				}
				else {
					$complianceState = $nonCompliant
				}
				$noOfNSXTConfigurations++
				$currentValue = $t1GwLogging
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			else{
				$complianceState = "Not Applicable"
				$noOfNSXTConfigurations++
				$currentValue = "Resource not Configured"
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			#TNDM-3X-000101
			$label = "VI-NET-AUD-01501"
			$confLabel = "$RegulatoryStandard-$label"
			
			$http = Get-NsxtService -Name "com.vmware.nsx.node.services.http"
			$protocolVersions = $http.get().service_properties.protocol_versions
			$hash = @{}
			foreach($protocolVersion in $protocolVersions){
				$hash[$protocolVersion.name] = $protocolVersion.enabled
			}
			
			if(($hash["TLSv1.1"] -eq $false) -and ($hash["TLSv1.2"] -eq $true)){
				$complianceState = $compliant
			}
			else {
				$complianceState = $nonCompliant
			} 
			$noOfNSXTConfigurations++
			$currentValue = "TLSv1.1 : " + $hash["TLSv1.1"] + " TLSv1.2 : " + $hash["TLSv1.2"]

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			$label = "VI-NET-AUD-01401"
			$confLabel = "$RegulatoryStandard-$label"
			
			$ntp = Get-NsxtService -Name "com.vmware.nsx.node.services.ntp"
			$ntpServers = $ntp.get().service_properties
			$count = 0
			foreach($ntpServer in $ntpServers){
				$count++
			}
			if($count -ge 2){
				$complianceState = $compliant
			}
			else {
				$complianceState = $nonCompliant
			} 
			$noOfNSXTConfigurations++
			$currentValue = $count

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}

			$label = "VI-NET-AUD-01420"
			$confLabel = "$RegulatoryStandard-$label"
			
			$async = Get-NsxtService "com.vmware.nsx.node.services.async_replicator"
			$asyncLogLevel = $async.get().service_properties.logging_level
			$http = Get-NsxtService "com.vmware.nsx.node.services.http"
			$httpLogLevel = $http.get().service_properties.logging_level
			$manager = Get-NsxtService "com.vmware.nsx.node.services.manager"
			$managerLogLevel = $manager.get().service_properties.logging_level
			$policy = Get-NsxtService "com.vmware.nsx.node.services.policy"
			$policyLogLevel = $policy.get().service_properties.logging_level
			
			if($asyncLogLevel -eq "INFO" -and $httpLogLevel -eq "INFO" -and $managerLogLevel -eq "INFO" -and $policyLogLevel -eq "INFO"){
				$complianceState = $compliant
			}
			else {
				$complianceState = $nonCompliant
			} 
			$noOfNSXTConfigurations++
			$currentValue = "async_replicator_loglevel : " + $asyncLogLevel + ", http_loglevel : " + $httpLogLevel + ", manager_loglevel : " + $managerLogLevel + ", policy_loglevel : " + $policyLogLevel

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			#TNDM-3X-000052
			$label = "VI-NET-AUD-01416"
			$confLabel = "$RegulatoryStandard-$label"

			$httpSessionTimeout = Get-NsxtService -Name "com.vmware.nsx.node.services.http"
			$httpSessionTimeout = $httpSessionTimeout.get().service_properties.session_timeout
			
			if($httpSessionTimeout -eq $configData.$product.$label.DesiredValue ){
				$complianceState = $compliant
			}
			else {
				$complianceState = $nonCompliant
			} 
			$noOfNSXTConfigurations++
			$currentValue = $httpSessionTimeout

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			#TNDM-3X-000052
			$label = "VI-NET-AUD-01499"
			$confLabel = "$RegulatoryStandard-$label"
			
			$cliTimeout = Get-NsxtService "com.vmware.nsx.node"
			$cliTimeout = $cliTimeout.get().cli_timeout
			
			if($cliTimeout -eq $configData.$product.$label.DesiredValue){
				$complianceState = $compliant
			}
			else {
				$complianceState = $nonCompliant
			} 
			$noOfNSXTConfigurations++
			$currentValue = $cliTimeout

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			#T0RT-3X-000067
			$label = "VI-NET-AUD-01460"
			$confLabel = "$RegulatoryStandard-$label"
			
			$logicalRouters = Get-NsxtService -Name com.vmware.nsx.logical_routers
			$tier0Router = $logicalRouters.list().results | Where-Object {$_.router_type -eq "TIER0"}
			
			if($tier0Router){
				$bgp = Get-NsxtService -Name com.vmware.nsx.logical_routers.routing.bgp.neighbors  
				$bgpNeighborConfig = $bgp.list($tier0Router.id).results.address_families
				
				$flag=0
				$routes=0
				foreach($config in $bgpNeighborConfig){            
					if(!$config.maximum_routes){
						$flag=1
						$routes = $config.maximum_routes
						break
					}
				}
				
				if($flag -eq 0){
					$complianceState = $compliant
				}
				else {
					$complianceState = $nonCompliant
				} 
				$noOfNSXTConfigurations++
				$currentValue = $routes

				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			else{
				$complianceState = "Not Applicable"
				$noOfNSXTConfigurations++
				$currentValue = "Resource not Configured"
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			#TNDM-3X-000080
			$label = "VI-NET-AUD-01423"
			$confLabel = "$RegulatoryStandard-$label"
			
			$http = Get-NsxtService -Name "com.vmware.nsx.node.services.http"
			$clientApiRateLimit = $http.get().service_properties.client_api_rate_limit
			$clientApiConcurrencyLimit = $http.get().service_properties.client_api_concurrency_limit
			$globalApiConcurrencyLimit = $http.get().service_properties.global_api_concurrency_limit
			
			if($clientApiRateLimit -eq 100 -and $clientApiConcurrencyLimit -eq 40 -and $globalApiConcurrencyLimit -eq 199){
				$complianceState = $compliant
			}
			else {
				$complianceState = $nonCompliant
			} 
			$noOfNSXTConfigurations++
			$currentValue = "client_api_rate_limit : " + $clientApiRateLimit + ", client_api_concurrency_limit : " + $clientApiConcurrencyLimit + ", global_api_concurrency_limit : " + $globalApiConcurrencyLimit

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			#TNDM-3X-000099
			$label = "VI-NET-AUD-01477"
			$confLabel = "$RegulatoryStandard-$label"
			
			$ssh = Get-NsxtService -Name "com.vmware.nsx.node.services.ssh"
			$startOnBoot = $ssh.get().service_properties.start_on_boot

			$sshStatus = Get-NsxtService -Name "com.vmware.nsx.node.services.ssh.status"
			$serviceState = $sshStatus.get().runtime_state
			
			if($startOnBoot -eq $false -and $serviceState -eq "stopped" ){
				$complianceState = $compliant
			}
			else {
				$complianceState = $nonCompliant
			} 
			$noOfNSXTConfigurations++
			$currentValue = "Service State : " + $serviceState + ", Start on boot : " + $startOnBoot

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			#TNDM-3X-000100
			$label = "VI-NET-AUD-01500"
			$confLabel = "$RegulatoryStandard-$label"
			
			$users = Get-NsxtService -Name com.vmware.nsx.node.users
			$auditUser = $users.list().results | Where-Object {$_.username -eq "audit"} | Select-Object status
			$guestUser1 = $users.list().results | Where-Object {$_.username -eq "guestuser1"} | Select-Object status
			$guestUser2 = $users.list().results | Where-Object {$_.username -eq "guestuser2"} | Select-Object status
			 
			if($auditUser.status -eq "NOT_ACTIVATED" -AND $guestUser1.status -eq "NOT_ACTIVATED" -AND $guestUser2.status -eq "NOT_ACTIVATED"){
				$complianceState = $compliant
			}
			else {
				$complianceState = $nonCompliant
			} 
			$noOfNSXTConfigurations++
			$currentValue = "audit : " + $auditUser.status + ", guestuser1 : " + $guestUser1.status + ", guestuser2 : " + $guestUser2.status

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			
			#TNDM-3X-000069
			$label = "VI-NET-AUD-01465"
			$confLabel = "$RegulatoryStandard-$label"
			
			$authPolicy = Get-NsxtService -Name com.vmware.nsx.node
			$timezone = $authPolicy.get().timezone
			
			if($timezone -like "*UTC*" -OR $timezone -like "*GMT*"){
				$complianceState = $compliant
			}
			else {
				$complianceState = $nonCompliant
			} 
			$noOfNSXTConfigurations++
			$currentValue = $timezone

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			#TNDM-3X-000097
			$label = "VI-NET-AUD-01509"
			$confLabel = "$RegulatoryStandard-$label"
			
			$node = Get-NsxtService com.vmware.nsx.node
			$nodeVersion = $node.get().product_version

			if($nodeVersion -ge "3.1.0.0.0.17107167"){
				$complianceState = $compliant
			}
			else {
				$complianceState = $nonCompliant
			} 
			
			$noOfNSXTConfigurations++
			$currentValue = $nodeVersion

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			#TNDM-3X-000102
			$label = "VI-NET-AUD-01502"
			$confLabel = "$RegulatoryStandard-$label"
			
			$snmp = Get-NsxtService -Name com.vmware.nsx.node.services.snmp
			$v2cConfigured = $snmp.get().service_properties.v2_configured

			if($v2cConfigured -eq $false){
				$complianceState = $compliant
			}
			else {
				$complianceState = $nonCompliant
			} 
			
			$noOfNSXTConfigurations++
			$currentValue = $v2cConfigured

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}

			
			#TNDM-3X-000093
			$label = "VI-NET-AUD-01468"
			$confLabel = "$RegulatoryStandard-$label"
			
			$backup = Get-NsxtService -Name com.vmware.nsx.cluster.backups.config
			$backupEnabled = $backup.get().backup_enabled
			$backupSchedule = $backup.get().backup_schedule.resource_type
			
			if($backupEnabled -eq $true -and $backupSchedule){
				$complianceState = $compliant
			}
			else {
				$complianceState = $nonCompliant
			} 
			$noOfNSXTConfigurations++
			$currentValue = "backupEnabled : " + $backupEnabled + ", backupSchedule : " + $backupSchedule

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			#T0FW-3X-000029
			$label = "VI-NET-AUD-01454"
			$confLabel = "$RegulatoryStandard-$label"
			
			$logicalRouters = Get-NsxtService -Name com.vmware.nsx.logical_routers
			$tier0Router = $logicalRouters.list().results | Where-Object {$_.router_type -eq "TIER0"}
			
			if($tier0Router){
				$logicalRouters = Get-NsxtService -Name com.vmware.nsx.logical_routers.status
				$transportNodes = $logicalRouters.get($tier0Router.id).per_node_status.transport_node_id
				$noOfTransportNodes = $transportNodes | Measure-Object -Line
				
				if($noOfTransportNodes.Lines -ge 2){
					$complianceState = $compliant
				}
				else {
					$complianceState = $nonCompliant
				} 
				$noOfNSXTConfigurations++
				$currentValue = $noOfTransportNodes.Lines

				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			else{
				$complianceState = "Not Applicable"
				$noOfNSXTConfigurations++
				$currentValue = "Resource not Configured"
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			#T0RT-3X-000051
			$label = "VI-NET-AUD-01469"
			$confLabel = "$RegulatoryStandard-$label"
			
			$tier0 = Get-NsxtPolicyService -Name "com.vmware.nsx_policy.infra.tier0s"
			$tier0_Id = $tier0.list().results.id
			
			if($tier0_Id){
				$localServices = Get-NsxtpolicyService -Name "com.vmware.nsx_policy.infra.tier_0s.locale_services"
				$locale_services_id = $localServices.list($tier0_Id).results.id
				  
				  
				$interface = Get-NSXtPolicyService -name com.vmware.nsx_policy.infra.tier_0s.locale_services.interfaces 
				$urpfMode = $interface.list($tier0_Id,$locale_services_id).results.urpf_mode
				$flag=0
				$urpfModeValue = ""
				foreach($mode in $urpfMode){
					if($mode -ne "STRICT"){
						$flag=1
						$urpfModeValue=$mode
						break
					}
					$urpfModeValue=$mode
				}
				if($flag -eq 0){
					$complianceState = $compliant
				}
				else {
					$complianceState = $nonCompliant
				} 
				$noOfNSXTConfigurations++
				$currentValue = $urpfModeValue

				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			else{
				$complianceState = "Not Applicable"
				$noOfNSXTConfigurations++
				$currentValue = "Resource not Configured"
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			<#T0RT-3X-000095
			$label = "VI-NET-AUD-01504"
			$confLabel = "$RegulatoryStandard-$label"
			
			$logicalRouters = Get-NsxtService -Name com.vmware.nsx.logical_routers
			$tier0Router = $logicalRouters.list().results | Where-Object {$_.router_type -eq "TIER0"}
			
			if($tier0Router){
				$localServices = Get-NsxtpolicyService -Name "com.vmware.nsx_policy.infra.tier_0s.locale_services"
				$locale_services_id = $localServices.list($tier0_Id).results.id
				
				$bgp = Get-NsxtService -Name com.vmware.nsx.logical_routers.routing.bgp 
				$bgpStatus = $bgp.get($tier0Router.id).enabled

				$ospf = Get-NsxtPolicyService -Name com.vmware.nsx_policy.infra.tier_0s.locale_services.ospf
				$ospfStatus = $ospf.get($tier0Router.display_name,$locale_services_id).enabled 
				
				$flag=0
				if($bgpStatus -eq $true -or $ospfStatus -eq $true){
					Write-Verbose "===$confLabel===" -ForegroundColor magenta
					Write-Verbose "The status of BGP is : $bgpStatus and the status of OSPF is : $ospfStatus"
					$check = Read-Host -Prompt "Are the enabled protocols in use  - Yes/No?"
					if($check -notlike "y*" ){
						$flag=1
					}
				}
				if($flag -eq 0 ){
					$complianceState = $compliant
				}
				else{
					$complianceState = $nonCompliant
				}
				
				$noOfNSXTConfigurations++
				$currentValue = "BGP Status : " + $bgpStatus + ", OSPF Status : " + $ospfStatus

				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}#>
			
			#T0RT-3X-000016
			$label = "VI-NET-AUD-01438"
			$confLabel = "$RegulatoryStandard-$label"
			
			$logicalRouters = Get-NsxtService -Name com.vmware.nsx.logical_routers
			$tier0Router = $logicalRouters.list().results | Where-Object {$_.router_type -eq "TIER0"}
			
			if($tier0Router){
				$interface = Get-NSXtPolicyService -name com.vmware.nsx_policy.infra.tier_0s.locale_services.interfaces
				$tier0ListOfInterfaces = $interface.list($tier0Router.display_name,$locale_services_id).results.display_name
				if($tier0ListOfInterfaces){
					$currentValue = "Site-Specific"	
					if($inputSpecData.$product.$label.DesiredValue -eq "Yes"){
						$complianceState = $compliant
					}
					else{
						$complianceState = $nonCompliant
					}
				}
				else{
					$complianceState = $compliant
					$currentValue = "No Interfaces available on Tier-0 Gateway."
				}
				$noOfNSXTConfigurations++

				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			else{
				$complianceState = "Not Applicable"
				$noOfNSXTConfigurations++
				$currentValue = "Resource not Configured"
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			#T1RT-3X-000016
			$label = "VI-NET-AUD-01442"
			$confLabel = "$RegulatoryStandard-$label"
			
			$logicalRouters = Get-NsxtService -Name com.vmware.nsx.logical_routers
			$tier1Router = $logicalRouters.list().results | Where-Object {$_.router_type -eq "TIER1"}
			
			if($tier1Router){
				$interface = Get-NSXtPolicyService -name com.vmware.nsx_policy.infra.tier_1s.locale_services.interfaces
				$tier1ListOfInterfaces = $interface.list($tier1Router.display_name,$locale_services_id).results.display_name
				if($tier1ListOfInterfaces){
					$currentValue = "Site-Specific"	
					if($inputSpecData.$product.$label.DesiredValue -eq "Yes"){
						$complianceState = $compliant
					}
					else{
						$complianceState = $nonCompliant
					}
				}
				else{
					$complianceState = $compliant
					$currentValue = "No Interfaces available on Tier-1 Gateway."
				}		
				$noOfNSXTConfigurations++

				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			else{
				$complianceState = "Not Applicable"
				$noOfNSXTConfigurations++
				$currentValue = "Resource not Configured"
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			#TNDM-3X-000103
			$label = "VI-NET-AUD-01508"
			$confLabel = "$RegulatoryStandard-$label"
			
			$globalConfig = Get-NsxtPolicyService -Name "com.vmware.nsx_policy.infra.global_config"
			$fipsMode = $globalConfig.get().fips
			

			if($fipsMode.lb_fips_enabled -eq $true){
				$complianceState = $compliant
			}
			else{
				$complianceState = $nonCompliant
			}
			
			$noOfNSXTConfigurations++
			$currentValue = $fipsMode.lb_fips_enabled

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			$label = "VI-NET-AUD-01410"
			$confLabel = "$RegulatoryStandard-$label"
			
			$usersAndRoles = Get-NsxtService -Name com.vmware.nsx.aaa.role_bindings
			$usersAndRoles = $usersAndRoles.list().results
				
			if($inputSpecData.$product.$label.DesiredValue -eq "Yes"){
				$complianceState = $compliant
			}
			else{
				$complianceState = $nonCompliant
			}
				
			$noOfNSXTConfigurations++
			$currentValue = "Site-Specific"

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
		}
		else{
			throw "Resolve connectivity issue of $nsxt and run the audit again."
		}
		
		#API Based Configurations
			if($domainName -eq "All"){
				$nsxtCredentials = Get-VCFCredential | Where-Object {$_.credentialType -eq "API" -and $_.resource.resourceType -eq "NSXT_MANAGER" -and $_.resource.resourceId -eq $vcfCredentials["nsxtClusterNodesList"][$nsxt]} | Select-Object username, password
				$user = $nsxtCredentials.userName
				$pass = $nsxtCredentials.password
			
			}	
			else{
				$user = $vcfCredentials["nsxtUsername"].username
				$pass = $vcfCredentials["nsxtPassword"].password
			}
			$pair = "$($user):$($pass)"
			$encodedCreds = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($pair))
			$basicAuthValue = "Basic $encodedCreds"

			$headers = @{
				Authorization = $basicAuthValue
			}
			
			$label = "VI-NET-AUD-01505"
			$confLabel = "$RegulatoryStandard-$label"
			$uri = "https://$nsxt/policy/api/v1/infra/tier-0s"
			$tier0Config = GetNsxtAPIMethod $uri $headers
			$tierZeroId = $tier0Config.results.id
			#$tier0DisplayName = $tier0Config.results.display_name
			#$tier0UniqueId = $tier0Config.results.unique_id
			
			$uri = "https://$nsxt/policy/api/v1/infra/tier-0s/$tierZeroId/locale-services"
			$tier0LocaleServicesConfig = GetNsxtAPIMethod $uri $headers
			
			$tier0LocaleServiceId = $tier0LocaleServicesConfig.results.id
			#$tier0LocaleServiceDisplayName = $tier0LocaleServicesConfig.results.display_name
			#$tier0LocaleServiceUniqueId = $tier0LocaleServicesConfig.results.unique_id
			if($tierZeroId){
				$uri = "https://$nsxt/policy/api/v1/infra/tier-0s/$tierZeroId/locale-services/$tier0LocaleServiceId/multicast"
				$tier0MulticastConfig = GetNsxtAPIMethod $uri $headers
				if($tier0MulticastConfig.enabled -eq $false -OR ($tier0MulticastConfig.enabled -eq $true -and $inputSpecData.$product.$label.DesiredValue -eq "Yes")){
					$complianceState = $compliant
				}
				else{
					$complianceState = $nonCompliant
				}
					
				$noOfNSXTConfigurations++
				$currentValue = $tier0MulticastConfig.enabled

				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			else{
				$complianceState = "Not Applicable"
				$noOfNSXTConfigurations++
				$currentValue = "Resource not Configured"
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			
			$label = "VI-NET-AUD-01507"
			$confLabel = "$RegulatoryStandard-$label"
			
			$uri = "https://$nsxt/policy/api/v1/infra/tier-1s"
			$tier1Config = GetNsxtAPIMethod $uri $headers
						
			$tierOneId = $tier1Config.results.id
			#$tier1DisplayNmae = $tier1Config.results.display_name
			#$tier1UniqueId = $tier1Config.results.unique_id
			if($tierOneId){
				$uri = "https://$nsxt/policy/api/v1/infra/tier-1s/$tierOneId/locale-services"
				$tier1LocaleServicesConfig = GetNsxtAPIMethod $uri $headers
				
				$tier1LocaleServiceId = $tier1LocaleServicesConfig.results.id
				#$tier1LocaleServiceDisplayName = $tier1LocaleServicesConfig.results.display_name
				#$tier1LocaleServiceUniqueId = $tier1LocaleServicesConfig.results.unique_id
				
				$uri = "https://$nsxt/policy/api/v1/infra/tier-1s/$tierOneId/locale-services/$tier1LocaleServiceId/multicast"
				$tier1MulticastConfig = GetNsxtAPIMethod $uri $headers
				if($tier1MulticastConfig.enabled -eq $false -OR ($tier1MulticastConfig.enabled -eq $true -and $inputSpecData.$product.$label.DesiredValue -eq "Yes")){
					$complianceState = $compliant
				}
				else{
					$complianceState = $nonCompliant
				}
					
				$noOfNSXTConfigurations++
				$currentValue = $tier1MulticastConfig.enabled

				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			else{
				$complianceState = "Not Applicable"
				$noOfNSXTConfigurations++
				$currentValue = "Resource not Configured"
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			
			$label = "VI-NET-AUD-01445"
			$confLabel = "$RegulatoryStandard-$label"
			
			$uri = "https://$nsxt/api/v1/node/services/ntp"
			$ntpConfig = GetNsxtAPIMethod $uri $headers

			if($ntpConfig.service_properties.servers -and $inputSpecData.$product.$label.DesiredValue -eq "Yes"){
				$complianceState = $compliant
			}
			else{
				$complianceState = $nonCompliant
			}
				
			$noOfNSXTConfigurations++
			$currentValue = $ntpConfig.service_properties.servers

			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			$label = "VI-NET-AUD-01449"
			$confLabel = "$RegulatoryStandard-$label"
			$uri = "https://$nsxt/api/v1/transport-nodes"
			$edgeNodesConfig = GetNsxtAPIMethod $uri $headers
			$edgeNodes = $edgeNodesConfig.results | Where-Object {$_.node_deployment_info.resource_type -eq "EdgeNode"}
			$flag = 0
			foreach($edgeNode in $edgeNodes){
				$edgeNodeId = $edgeNode.node_id
				$uri = "https://$nsxt/api/v1/transport-nodes/$edgeNodeId/node/services/ssh/status"
				$edgeNodesSshConfig = GetNsxtAPIMethod $uri $headers
				if($edgeNodesSshConfig.runtime_state -eq "running"){
					$flag = 1
					$currentValue = $edgeNodesSshConfig.runtime_state
				}
			}
			if($flag -eq 0){
				$complianceState = $compliant
				$currentValue = "Stopped"
			}
			else{
				$complianceState = $nonCompliant
			}
			$noOfNSXTConfigurations++
			if($RegulatoryStandard -eq "DISA"){
				$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			
			$label = "VI-NET-AUD-01504"
			$confLabel = "$RegulatoryStandard-$label"
			if($tierZeroId){
				$uri = "https://$nsxt/policy/api/v1/infra/tier-0s/$tierZeroId/locale-services/$tier0localeServiceId/bgp"
				$bgpConfig = GetNsxtAPIMethod $uri $headers
				
				$uri = "https://$nsxt/policy/api/v1/infra/tier-0s/$tierZeroId/locale-services/$tier0localeServiceId/ospf"
				$ospfConfig = GetNsxtAPIMethod $uri $headers
				
				if(($bgpConfig.enabled -OR $ospfConfig.enabled) -and ($inputSpecData.$product.$label.DesiredValue -eq "Yes")){
					$complianceState = $compliant
				}
				else{
					$complianceState = $nonCompliant
				}
				$noOfNSXTConfigurations++
				$currentValue = "BGP Status : " + $bgpConfig.enabled + ", OSPF Status : " + $ospfConfig.enabled
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}
			else{
				$complianceState = "Not Applicable"
				$noOfNSXTConfigurations++
				$currentValue = "Resource not Configured"
				if($RegulatoryStandard -eq "DISA"){
					$nsxtHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$nsxtHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			}

		$nsxtHashKey[$nsxt] = $nsxtHashInnerKey
		Disconnect-NsxtServer -Server $nsxt -Confirm:$false	
	}
	$fileName = $jsonName +"_"+ (Get-Date -Format "dd-MM-yyyy-hh-mm-ss")
	$nsxtHashKey | ConvertTo-Json | Out-File "$ReportPath\$fileName.json"
	Generate-Report $nsxtHashKey $jsonName $RegulatoryStandard $ReportPath
	<#Write-Verbose ""
	if($auditAllFlag -eq 0){
		Write-Output "Audit of $noOfNSXTConfigurations Configurations of NSX-T is done and report can be found at : $ReportPath\$fileName.json and $ReportPath\$fileName.xlsx"
	}#>
	
	$nsxtAuditDetails["jsonReportName"] = $fileName+".json"
	$nsxtAuditDetails["excelReportName"] = $fileName+".xlsx"
	$nsxtAuditDetails["reportPath"] = $ReportPath
	$nsxtAuditDetails["noOfNsxtConfigurationsAudited"] = $noOfNSXTConfigurations
		
		
	return $nsxtAuditDetails
}