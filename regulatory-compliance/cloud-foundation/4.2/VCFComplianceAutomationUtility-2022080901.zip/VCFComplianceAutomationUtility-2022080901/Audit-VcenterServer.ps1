Function Audit-VcenterServer
{
	<#

	.SYNOPSIS
	Audits vCenter Servers in VCF Environment.

	.DESCRIPTION
	This Cmdlet is used to audit vCenter Servers based on the regulatory standard and domain of interest.
	The regulatory standards supported are  NIST, PCI and DISA.
	More support will be added in the future.
	
	.EXAMPLE
	Audit-VcenterServer -RegulatoryStandard NIST -DomainName <Domain Name> -ReportPath <Path where reports and logs get saved>
	Audit-VcenterServer -RegulatoryStandard PCI -DomainName <Domain Name> -ReportPath <Path where reports and logs get saved>
	Audit-VcenterServer -RegulatoryStandard DISA -DomainName <Domain Name> -ReportPath <Path where reports and logs get saved>

	.NOTES
	Connect to VCF Server using Connect-VCFServer before running Audit-VcenterServer Cmdlet.
	
	#>
	
	Param(
		[ValidateSet("DISA","PCI","NIST",IgnoreCase=$true)]
		[Parameter(mandatory=$true)]
        [String]$RegulatoryStandard,
		[Parameter(mandatory=$true)]
        [String]$DomainName,
		[Parameter(mandatory=$true)]
		[ValidateScript({Test-Path $_})]
        [String]$ReportPath
	)
	
	$domainName = $DomainName.trim()
	$compliant="Pass"
	$nonCompliant="Fail"
	$vcenterAuditDetails = @{}
	if($vcfSession.Session -eq 0){
		Throw "You are not currently connected to SDDC Manager. Please connect using Connect-VCFServer cmdlet."
	}
	
	$configFileName = $RegulatoryStandard.toLower()+"Config.json"
	$filePath = Join-Path -Path $PSScriptRoot -ChildPath $configFileName
	$configData = (Get-Content -Path $filePath -Raw )  | ConvertFrom-Json
	
	$inputFileName = "inputSpec.json"
	$inputFilePath = Join-Path -Path $PSScriptRoot -ChildPath $inputFileName
	$inputSpecData = (Get-Content -Path $inputFilePath -Raw )  | ConvertFrom-Json
	$jsonName = $RegulatoryStandard.toUpper() + "_" + $domainName + "_Vcenter"
	$product = "vCenter"
									 
	
	$vcfCredentials = Select-Domain $domainName
	
	if($domainName -eq "All"){
			Write-Progress " Auditing vCenter Servers of $domainName the Workload Domains:"
	}
	else{
		Write-Progress " Auditing vCenter Server of $domainName Workload Domain"
	}
	
	$noOfvCenters
	$vCenterHashKey = @{}
	
	Foreach($vc in $vcfCredentials["vCenterList"].fqdn){
		$vCenterHashInnerKey = @{}
		$logName = $RegulatoryStandard.toUpper() + "_auditVcenter"
		$connection = Connect-viserver -Server $vc -username $vcfCredentials["vcusername"] -password $vcfCredentials["vcpassword"] -ErrorAction SilentlyContinue
		if($connection)
		{
			Write-Progress "*********   Auditing $vc ...   *********"
			$noOfvCenterConfigurations = 0
			
			$label = "VI-VC-AUD-00404"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			$property = Get-AdvancedSetting -Entity $vc -Name config.log.level | Select-Object Name,Value
			if ($property.value -eq "info")
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $property.Value
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
				
			$label = "VI-VC-AUD-00405"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			$switchPromiscuousMode = Get-VDSwitch | Get-VDSecurityPolicy
			$portgroupPromiscuousMode = Get-VDPortgroup | Get-VDSecurityPolicy
			$flag = 0
			Foreach ($setting in $switchPromiscuousMode.AllowPromiscuous){
				if ($setting -eq "true")
				{
					$flag = 1
					break
				}
			}
			Foreach ($setting in $portgroupPromiscuousMode.AllowPromiscuous){
				if ($setting -eq "true")
				{
					$flag = 1
					break
				}
			}
			if ($flag -eq 0)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $setting
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}

			$label = "VI-VC-AUD-00407"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			$switchMacChanges = Get-VDSwitch | Get-VDSecurityPolicy
			$portgroupMacChanges = Get-VDPortgroup | Get-VDSecurityPolicy
			$flag = 0
			Foreach ($setting in $switchMacChanges.MacChanges){
				if ($setting -eq "true")
				{
					$flag = 1
					break
				}
			}
			Foreach ($setting in $portgroupMacChanges.MacChanges){
				if ($setting -eq "true")
				{
					$flag = 1
					break
				}
			}
			if ($flag -eq 0)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $setting
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			$label = "VI-VC-AUD-00409"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			$niocs = Get-VDSwitch | Select-Object Name,@{N="NIOC Enabled";E={$_.ExtensionData.config.NetworkResourceManagementEnabled}}
			$flag = 0
			Foreach ($setting in $niocs){
				if ($setting."NIOC Enabled" -eq $False)
				{
					$flag = 1
					break
				}
			}
			if ($flag -eq 0)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $setting."NIOC Enabled"
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			
			$label = "VI-VC-AUD-00417"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			$netFlow = Get-VDPortgroup | Select-Object Name,VirtualSwitch,@{N="NetFlowEnabled";E={$_.Extensiondata.Config.defaultPortConfig.ipfixEnabled.Value}}
			$flag = 0
			Foreach ($setting in $netFlow.NetFlowEnabled){
				if ($setting -eq $True)
				{
					$flag = 1
					break
				}
			}
			if ($flag -eq 0)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $setting
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			$label = "VI-VC-AUD-00420"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			$clusters = Get-Cluster | Where-Object {$_.VsanEnabled}
			$flag = 0
			Foreach ($cluster in $clusters){
				$clus = $cluster | Get-Datastore | Where-Object {$_.type -match "vsan"}
				if($clus.Name -eq "vsanDatastore"){
					$flag = 1
				}
			}
			if ($flag -eq 0)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $clus.Name
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			$label = "VI-VC-AUD-00427"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			$property = Get-AdvancedSetting -Entity $vc -Name config.vpxd.hostPasswordLength | Select-Object Name,Value
			if (!$property -OR $property.value -eq "32")
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $property.value
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			$label = "VI-VC-AUD-00428"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			$property = Get-AdvancedSetting -Entity $vc -Name VirtualCenter.VimPasswordExpirationInDays | Select-Object Name,Value
			if ($property.value -eq "30")
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $property.value
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			$label = "VI-VC-AUD-00450"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			$switchForgedTransmits = Get-VDSwitch | Get-VDSecurityPolicy
			$portgroupForgedTransmits = Get-VDPortgroup | Where-Object {$_.IsUplink -eq $false} | Get-VDSecurityPolicy
			$flag = 0
			Foreach ($setting in $switchForgedTransmits.ForgedTransmits){
				if ($setting -eq "true")
				{
					$flag = 1
					break
				}
			}
			Foreach ($setting in $portgroupForgedTransmits.ForgedTransmits){
				if ($setting -eq "true")
				{
					$flag = 1
					break
				}
			}
			if ($flag -eq 0)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $setting
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			$flag=0
			$label = "VI-VC-AUD-01200"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			$vds = Get-VDSwitch
			$vdsSetting = $vds.ExtensionData.Config.HealthCheckConfig
			Foreach ($setting in $vdsSetting){
				if($setting.Enable -ne $False){
					   $flag = 1
					   break
				}
			}
			if ($flag -eq 0)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $setting.Enable
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			$label = "VI-VC-AUD-01219"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			$Alarm = Get-AlarmDefinition | Where-Object {$_.ExtensionData.Info.Expression.Expression.EventTypeId -eq "com.vmware.sso.PrincipalManagement"} | Select-Object Name,Enabled,@{N="EventTypeId";E={$_.ExtensionData.Info.Expression.Expression.EventTypeId}}
			if ($Alarm)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $Alarm.EventTypeId
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			$label = "VI-VC-AUD-01221"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			$property = Get-AdvancedSetting -Entity $vc -Name vpxd.event.syslog.enabled | Select-Object Name,Value
			if ($property.value -eq $True)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $property.value
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			#vCenter API based Configurations
					
			<#$pair = "$($vcusername):$($vcpassword)"
			$encodedCreds = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($pair))
			$basicAuthValue = "Basic $encodedCreds"

			$headers = @{
				Authorization = $basicAuthValue
			}

			$apiSessionParams = @{
				uri = "https://$vc/api/session"
				Headers = $headers
				Method = "Post"
			}

			$apiSessionKey = try {
				Invoke-RestMethod @apiSessionParams
			} 
			catch{
				$_.Exception.Response
			}#>

			
			
			<#$vCenterSettingsParams = @{
				uri = "https://$vc/api/appliance/vcenter/settings/v1/config-current"
				Headers = @{'vmware-api-session-id'=$apiSessionKey}
				Method = "Get"
			}

			$vCenterSettingsConfig = try {
				Invoke-RestMethod @vCenterSettingsParams
			} 
			catch{
				$_.Exception.Response
			}#>
			
			$apiSessionKey = generateAPISessionKey $vc $vcfCredentials["vcusername"] $vcfCredentials["vcpassword"]
			$uri = "https://$vc/api/appliance/vcenter/settings/v1/config-current"
			$vCenterSettingsConfig = GetvCenterAPIMethod $uri $apiSessionKey
			
			$label = "VI-VC-AUD-00408"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			
			if ($vCenterSettingsConfig.authmgmt.password_policy.uppercase_chars -eq $configData.$product.$label.DesiredValue)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $vCenterSettingsConfig.authmgmt.password_policy.uppercase_chars
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			$label = "VI-VC-AUD-00413"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			
			if ($vCenterSettingsConfig.authmgmt.password_policy.lowercase_chars -eq $configData.$product.$label.DesiredValue)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $vCenterSettingsConfig.authmgmt.password_policy.lowercase_chars
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			$label = "VI-VC-AUD-00432"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			
			if ($vCenterSettingsConfig.authmgmt.password_policy.special_chars -eq $configData.$product.$label.DesiredValue)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $vCenterSettingsConfig.authmgmt.password_policy.special_chars
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			
			$label = "VI-VC-AUD-00433"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			
			if ($vCenterSettingsConfig.authmgmt.password_policy.numeric_chars -eq $configData.$product.$label.DesiredValue)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $vCenterSettingsConfig.authmgmt.password_policy.numeric_chars
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			
			$label = "VI-VC-AUD-00434"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			
			if ($vCenterSettingsConfig.authmgmt.lockout_policy.failure_interval -ge $configData.$product.$label.DesiredValue)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$DesiredValue = "Atleast "+$configData.$product.$label.DesiredValue
			$currentValue = $vCenterSettingsConfig.authmgmt.lockout_policy.failure_interval
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $DesiredValue $complianceState
			}
			
			$label = "VI-VC-AUD-00435"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			
			if ($vCenterSettingsConfig.authmgmt.lockout_policy.unlock_time -eq $configData.$product.$label.DesiredValue)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $vCenterSettingsConfig.authmgmt.lockout_policy.unlock_time
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			$label = "VI-VC-AUD-00436"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			
			if ($vCenterSettingsConfig.authmgmt.lockout_policy.failed_login_attempts -eq $configData.$product.$label.DesiredValue)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $vCenterSettingsConfig.authmgmt.lockout_policy.failed_login_attempts
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			$label = "VI-VC-AUD-00403"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			
			if ($vCenterSettingsConfig.authmgmt.password_policy.password_reuse -eq $configData.$product.$label.DesiredValue)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $vCenterSettingsConfig.authmgmt.password_policy.password_reuse
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			
			$label = "VI-VC-AUD-00421"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			
			if ($vCenterSettingsConfig.authmgmt.password_policy.max_life -eq $configData.$product.$label.DesiredValue)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $vCenterSettingsConfig.authmgmt.password_policy.max_life
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}

			$label = "VI-VC-AUD-00410"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			
			if ($vCenterSettingsConfig.authmgmt.password_policy.min_length -eq $configData.$product.$label.DesiredValue)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $vCenterSettingsConfig.authmgmt.password_policy.min_length
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			$label = "VI-VC-AUD-01218"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			
			$uri = "https://$vc/api/appliance/logging/forwarding"
			$syslogSettingsConfig = GetvCenterAPIMethod $uri $apiSessionKey
			
			if($syslogSettingsConfig){
				$body = @{
					send_test_message = $false
				} | ConvertTo-Json

				$uri = "https://$vc/api/appliance/logging/forwarding?action=test"
				$syslogTestSettingsConfig = PostvCenterAPIMethod $uri $apiSessionKey $body
				
				if ($syslogTestSettingsConfig.state -eq "UP")
				{
					$complianceState = $compliant
				}
				else
				{
					$complianceState = $nonCompliant
				}
				$currentValue = $syslogSettingsConfig.hostname + " : " + $syslogTestSettingsConfig.state
				if($RegulatoryStandard -eq "DISA"){
					$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			
			}
			else{
				$complianceState = $nonCompliant
				$currentValue = "Syslog not Configured"
				if($RegulatoryStandard -eq "DISA"){
					$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
				else{
					$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
				}
			
			}
			
			$label = "VI-VC-AUD-01205"
			$confLabel = "$RegulatoryStandard-$label"
			$uri = "https://$vc/api/vcenter/certificate-management/vcenter/tls"
			$machineSSLCertConfig = GetvCenterAPIMethod $uri $apiSessionKey

			$noOfvCenterConfigurations++
			if ($inputSpecData.$product.$label.DesiredValue -eq "Yes")
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue  = $machineSSLCertConfig.issuer_dn
			
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			$label = "VI-VC-AUD-01201"
			$confLabel = "$RegulatoryStandard-$label"
			$vlanConfig = Get-VDPortgroup | Select-Object Name, VlanConfiguration
			$vlanIds = $vlanConfig.VlanConfiguration
			$flag = 0
			$noOfvCenterConfigurations++
			Foreach ($setting in $vlanIds.VlanId){
				if ($setting -eq $inputSpecData.$product.$label.NativeVlanId)
				{
					$flag = 1
					break
				}
			}
			if ($flag -eq 0)
			{
				$complianceState = $compliant
				$currentValue  = "None of the port groups configured with native VLAN ID"
			}
			else
			{
				$complianceState = $nonCompliant
				$currentValue  = "One of the port groups configured with native VLAN ID"
			}
			#$currentValue  = "Site-Specific"
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			
			$label = "VI-VC-AUD-01202"
			$confLabel = "$RegulatoryStandard-$label"
			$vlanConfig = Get-VDPortgroup | Select-Object Name, VlanConfiguration
			$vlanIds = $vlanConfig.VlanConfiguration
			$flag = 0
			$noOfvCenterConfigurations++
			Foreach ($setting in $vlanIds.VlanId){
				if ($setting -eq $inputSpecData.$product.$label.ReservedVlanId)
				{
					$flag = 1
					break
				}
			}
			if ($flag -eq 0)
			{
				$complianceState = $compliant
				$currentValue  = "None of the port groups configured with reserved VLAN ID"
			}
			else
			{
				$complianceState = $nonCompliant
				$currentValue  = "One of the port groups configured with reserved VLAN ID"
			}
			#$currentValue  = "Site-Specific"
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			$label = "VI-VC-AUD-01240"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			$property = Get-AdvancedSetting -Entity $vc -Name $configData.$product.$label.ParameterName | Select-Object Name,Value
			if ($property.value -eq $configData.$product.$label.DesiredValue)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $property.value
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}

			$label = "VI-VC-AUD-01226"
			$confLabel = "$RegulatoryStandard-$label"
			$noOfvCenterConfigurations++
			$eventRetention = Get-AdvancedSetting -Entity $vc -Name event.maxAge | Select-Object Name,Value
			$taskRetention = Get-AdvancedSetting -Entity $vc -Name task.maxAge | Select-Object Name,Value
			if ($eventRetention.value -ge $configData.$product.$label.DesiredValue -and $taskRetention.value -ge $configData.$product.$label.DesiredValue)
			{
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = "Task Retention : " + $taskRetention.Value + ", Event Retention : " + $eventRetention.Value
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			$label = "VI-VC-AUD-01238"
			$confLabel = "$RegulatoryStandard-$label"
			$snmpRecievers = Get-AdvancedSetting -Entity $vc -Name "snmp*" | Where-Object {$_.Name -like "snmp.receiver.*.enabled*"}
			$flag = 0
			$noOfvCenterConfigurations++
			foreach($property in $snmpRecievers){
				if($property.Vlue -eq $true){
					$flag = 1
					break
				}
			}
			if($flag -eq 0){
				$complianceState = $compliant
				$currentValue = $false
			}
			else
			{
				$complianceState = $nonCompliant
				$currentValue = $true
			}

			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
			<#$label = "VI-VC-AUD-00422"
			$confLabel = "$RegulatoryStandard-$label"
			$VCFComponents = Get-VCFCredential
			Foreach ($component in $VCFComponents){
				#if($component.resource.resourceType -eq "VCENTER" -and $component.resource.domainName -eq $domainName -and $component.resource.resourceName -eq $vc -and $component.credentialType -eq "SSH"){
				if($component.resource.resourceType -eq "VCENTER" -and $component.resource.resourceName -eq $vc -and $component.credentialType -eq "SSH"){
					$domainDetails = getDomainDetails($component.resource.domainName)
					
					$vCenterVmName = $component.resource.resourceName.split(".")[0]
					$vCenterVmUsername = $component.username
					$vCenterVmPassword = $component.password
				}
			}
			
			if($domainDetails["domainType"] -eq "VI"){
				$vcConnection = Connect-viserver -Server $vcfCredentials["managementVc"] -username $vcfCredentials["vcusername"] -password $vcfCredentials["vcpassword"] -ErrorAction SilentlyContinue
				if($vcConnection)
				{
					$vm = Get-VM -Name $vCenterVmName
					$script = "grep session\.timeout /etc/vmware/vsphere-ui/webclient.properties"
					$noOfvCenterConfigurations++
					$output = Invoke-VMScript -vm $vm -ScriptText $script  -ScriptType Bash -GuestUser $vCenterVmUsername -GuestPassword $vCenterVmPassword
					disconnect-viserver -Server $vcfCredentials["managementVc"] -Confirm:$false
				}
			}
			else{
				$vm = Get-VM -Name $vCenterVmName
				$script = "grep session\.timeout /etc/vmware/vsphere-ui/webclient.properties"
				$noOfvCenterConfigurations++
				$output = Invoke-VMScript -vm $vm -ScriptText $script -ScriptType Bash -GuestUser $vCenterVmUsername -GuestPassword $vCenterVmPassword
			}

			if($output.Contains("session.timeout")){
				$timeout = $output.Split("=")[1].split("")[1]
			}
			if($timeout -eq 10){
				$complianceState = $compliant
			}
			else
			{
				$complianceState = $nonCompliant
			}
			$currentValue = $timeout
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}#>
			
			$label = "VI-VC-AUD-01227"
			$confLabel = "$RegulatoryStandard-$label"
			$vlanConfig = Get-VDPortgroup | Where-Object {$_.ExtensionData.Config.Uplink -ne "True"} | Select-Object Name,VlanConfiguration
			$vlanIds = $vlanConfig.VlanConfiguration
			$flag = 0
			$noOfvCenterConfigurations++
			Foreach ($setting in $vlanIds){
				if($setting.VlanType -eq "Trunk"){
					$range = $setting.Ranges
					$flag = 1
					break;
				}
			}
			
			if($flag -eq 0){
				$complianceState = $compliant
				$currentValue = "No distributed portgroups with VLAN Trunk enabled"
			}
			elseif($flag -eq 1 -and $inputSpecData.$product.$label.DesiredValue -eq "Yes"){
				$complianceState = $compliant
				$currentValue = $range.StartVlanId.ToString() + "-" + $range.EndVlanId.ToString()
			}
			else{
				$complianceState = $nonCompliant
				$currentValue = $range.StartVlanId.ToString() + "-" + $range.EndVlanId.ToString()
			}
			
			if($RegulatoryStandard -eq "DISA"){
				$vCenterHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			else{
				$vCenterHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
			}
			
		}
		else{
			$logMessage = "Resolve connectivity issue of $vc and run the audit again." 
			$logMessage >> $ReportPath\\$logName.log
		}
		$vCenterHashKey[$vc] = $vCenterHashInnerKey	
		
		disconnect-viserver -Server $vc -Confirm:$false
	}
	$fileName = $jsonName +"_"+ (Get-Date -Format "dd-MM-yyyy-hh-mm-ss")
	$vCenterHashKey | ConvertTo-Json | Out-File "$ReportPath\$fileName.json"
	Generate-Report $vCenterHashKey $jsonName $RegulatoryStandard $ReportPath
	Write-Verbose ""
	<#if($auditAllFlag -eq 0){
		Write-Output "Audit of $noOfvCenterConfigurations configurations of vCenter is done and report can be found at $ReportPath\$fileName.json and $ReportPath\$fileName.xlsx"
	}#>
	
	$vcenterAuditDetails["jsonReportName"] = $fileName+".json"
	$vcenterAuditDetails["excelReportName"] = $fileName+".xlsx"
	$vcenterAuditDetails["reportPath"] = $ReportPath
	$vcenterAuditDetails["noOfVcenterConfigurationsAudited"] = $noOfvCenterConfigurations
		
		
	return $vcenterAuditDetails
}