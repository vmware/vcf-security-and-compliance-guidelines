Function Audit-All
{	
	<#

	.SYNOPSIS
	Audits all the components(ESXi, vCenter Server, Virtual Machine, NSX-T) in VCF Environment.

	.DESCRIPTION
	This Cmdlet is used to audit all the components(ESXi, vCenter Server, Virtual Machine, NSX-T) based on the regulatory standard and domain of interest.
	The regulatory standards tha are supported are  NIST, PCI and DISA.
	More support will be added in the future.
	
	.EXAMPLE
	Audit-All -RegulatoryStandard NIST -domainName <Domain Name> -ReportPath <Path where reports and logs get saved>
	Audit-All -RegulatoryStandard PCI -domainName <Domain Name> -ReportPath <Path where reports and logs get saved>
	Audit-All -RegulatoryStandard DISA -domainName <Domain Name> -ReportPath <Path where reports and logs get saved>

	.NOTES
	Connect to VCF Server using Connect-VCFServer before running Audit-All Cmdlet.
	
	#>
	
	Param(
		[ValidateSet("DISA","PCI","NIST",IgnoreCase=$true)]
		[Parameter(mandatory=$true)]
        [String]$RegulatoryStandard,
		[Parameter(mandatory=$true)]
        [String]$DomainName,
		[Parameter(mandatory=$true)]
        [String]$ReportPath
	)
	
	#$jsonPath = Get-Location
	$allAuditDetails = @{}
	if($vcfSession.Session -eq 0){
		Throw "You are not currently connected to SDDC Manager. Please connect using Connect-VCFServer cmdlet."
	}
	
	
	#$totalNoOfAuditConfigurations = 0
	#$Global:auditAllFlag = 1
	
	#Select-Domain
	$esxiAuditDetails = Audit-ESXiHost -RegulatoryStandard $RegulatoryStandard -DomainName $DomainName -ReportPath $ReportPath
	$vcenterAuditDetails = Audit-VcenterServer -RegulatoryStandard $RegulatoryStandard -DomainName $DomainName -ReportPath $ReportPath
	$vmAuditDetails = Audit-VirtualMachine -RegulatoryStandard $RegulatoryStandard -DomainName $DomainName -ReportPath $ReportPath
	$nsxtAuditDetails = Audit-NSXTManager -RegulatoryStandard $RegulatoryStandard -DomainName $DomainName -ReportPath $ReportPath
	$sddcAuditDetails = Audit-SDDCManager -RegulatoryStandard $RegulatoryStandard -ReportPath $ReportPath
	<#
	Write-Output "ESXi: "$esxiAuditDetails["noOfEsxiConfigurationsAudited"]
	Write-Output "vCenter: "$vcenterAuditDetails["noOfVcenterConfigurationsAudited"]
	Write-Output "Vm: "$vmAuditDetails["noOfVmConfigurationsAudited"]
	Write-Output "Nsxt: "$nsxtAuditDetails["noOfNsxtConfigurationsAudited"]
	Write-Output "Sddc: "$sddcAuditDetails["noOfSddcConfigurationsAudited"]
	#>
	
	#$allAuditDetails["TotalNoOfConfigurationsAudited"] = $esxiAuditDetails["noOfEsxiConfigurationsAudited"] + $vcenterAuditDetails["noOfVcenterConfigurationsAudited"] + $vmAuditDetails["noOfVmConfigurationsAudited"] + $nsxtAuditDetails["noOfNsxtConfigurationsAudited"] + $sddcAuditDetails["noOfSddcConfigurationsAudited"]
	$allAuditDetails["ReportsPath"] = $ReportPath
	 
	
	#Write-Output "Audit of $totalNoOfAuditConfigurations configurations of VCF is done and reports: $esxiReportName, $vcenterReportName, $vmReportName, $nsxtReportName and $sddcReportName can be found at : $jsonPath" -ForegroundColor magenta
	#$auditAllFlag = 0
	return $allAuditDetails
}