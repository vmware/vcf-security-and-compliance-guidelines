Function Audit-SDDCManager
{
	<#

	.SYNOPSIS
	Audits SDDC Manager.

	.DESCRIPTION
	This Cmdlet is used to audit SDDC Manager based on the regulatory standard.
	The regulatory standards supported are  NIST, PCI and DISA.
	More support will be added in the future.
	
	.EXAMPLE
	Audit-SDDCManager -RegulatoryStandard NIST -ReportPath <Path where reports and logs get saved>
	Audit-SDDCManager -RegulatoryStandard PCI -ReportPath <Path where reports and logs get saved>
	Audit-SDDCManager -RegulatoryStandard DISA -ReportPath <Path where reports and logs get saved>

	.NOTES
	Connect to VCF Server using Connect-VCFServer before running Audit-SDDCManager Cmdlet.
	
	#>
	
	Param(
		[ValidateSet("DISA","PCI","NIST",IgnoreCase=$true)]
		[Parameter(mandatory=$true)]
        [String]$RegulatoryStandard,
		[Parameter(mandatory=$true)]
		[ValidateScript({Test-Path $_})]
        [String]$ReportPath
	)
	
	$sddcAuditDetails = @{}
	$compliant="Pass"
	$nonCompliant="Fail"
	
	if($vcfSession.Session -eq 0){
		Throw "You are not currently connected to SDDC Manager. Please connect using Connect-VCFServer cmdlet."
	}
	
	$configFileName = $RegulatoryStandard.toLower()+"Config.json"
	$filePath = Join-Path -Path $PSScriptRoot -ChildPath $configFileName
	$configData = (Get-Content -Path $filePath -Raw )  | ConvertFrom-Json
	
	$inputFileName = "inputSpec.json"
	$inputFilePath = Join-Path -Path $PSScriptRoot -ChildPath $inputFileName
	$inputSpecData = (Get-Content -Path $inputFilePath -Raw )  | ConvertFrom-Json
	
	$jsonName = $RegulatoryStandard.toUpper() + "_SDDC"
	$product = "SDDC"
	
	$sddcHashKey = @{}
	$sddcHashInnerKey = @{}
	
	#$logName = $RegulatoryStandard.toUpper() + "_auditSDDC"
	$noOfSDDCConfigurations = 0
	$sddcServer = $vcfSession.SddcServer
	#Configure-SSL
	Write-Progress "*********   Auditing $sddcServer ...   *********"
	
	$headers = generateAccessToken $sddcServer $vcfSession.SddcUsername $vcfSession.SecretPassword
	
	#ControlID = CFAP-4X-000001
	$label = "VI-SDDC-AUD-1600"
	$confLabel = "$RegulatoryStandard-$label"
	
	$uri = "https://$sddcServer/v1/system/backup-configuration"
	$backupConfig = GetSDDCManagerAPIMethod $uri $headers
	
	$backupServer = $backupConfig.backupLocations.server
	$backupProtocol = $backupConfig.backupLocations.protocol
	$backupSchedule = $backupConfig.backupSchedules.frequency
	$backupScheduleConfig = $backupConfig.backupSchedules.takeScheduledBackups

	if($backupServer -and $backupProtocol -eq "SFTP" -and $backupSchedule -and $backupScheduleConfig -eq $true){
		$complianceState = $compliant
	}
	else{
		$complianceState = $nonCompliant
	}
	
	$noOfSDDCConfigurations++
	$currentValue = "backupServer : " + $backupServer + ", backupProtocol : " + $backupProtocol + ", backupSchedule : " + $backupSchedule + ", backupScheduleConfig : " + $backupScheduleConfig

	if($RegulatoryStandard -eq "DISA"){
		$sddcHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
	}
	else{
		$sddcHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
	}
	#ControlID = CFAP-4X-000002
	$label = "VI-SDDC-AUD-1601"
	$confLabel = "$RegulatoryStandard-$label"
	
	$uri = "https://$sddcServer/v1/system/ntp-configuration"
	$ntpConfig = GetSDDCManagerAPIMethod $uri $headers
	
	$ntpServer = $ntpConfig.ntpServers.ipAddress
	if($ntpServer){
		if($inputSpecData.$product.$label.DesiredValue -eq "Yes" ){
			$complianceState = $compliant
		}
		else{
			$complianceState = $nonCompliant
		}
	}
	else{
		$complianceState = $nonCompliant
	}
	
	$noOfSDDCConfigurations++
	$currentValue = "ntpServer : " + $ntpServer

	if($RegulatoryStandard -eq "DISA"){
		$sddcHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
	}
	else{
		$sddcHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
	}
	
	#ControlID = CFAP-4X-000007
	$label = "VI-SDDC-AUD-1606"
	$confLabel = "$RegulatoryStandard-$label"
	$uri = "https://$sddcServer/v1/system/ceip"
	$ceipConfig = GetSDDCManagerAPIMethod $uri $headers
	
	if($ceipConfig.status -eq "DISABLED"){
		$complianceState = $compliant
	}
	else{
		$complianceState = $nonCompliant
	}
	
	$noOfSDDCConfigurations++
	$currentValue = $ceipConfig.status

	if($RegulatoryStandard -eq "DISA"){
		$sddcHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
	}
	else{
		$sddcHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
	}
	
	#ControlID = CFAP-4X-000008
	$label = "VI-SDDC-AUD-1607"
	$confLabel = "$RegulatoryStandard-$label"
	
	$uri = "https://$sddcServer/v1/system/settings/depot"
	$depotConfig = GetSDDCManagerAPIMethod $uri $headers
	
	$username = $depotConfig.vmwareAccount.username
	
	
	if($username -and $inputSpecData.$product.$label.DesiredValue -eq "Yes" ){
		$complianceState = $compliant
		$currentValue = $username
	}
	else{
		$complianceState = $nonCompliant
		$currentValue = "Dedicated My VMware account is not configured"
	}
	
	$noOfSDDCConfigurations++

	if($RegulatoryStandard -eq "DISA"){
		$sddcHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
	}
	else{
		$sddcHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
	}
	
	#ControlID = CFAP-4X-000006
	$label = "VI-SDDC-AUD-1605"
	$confLabel = "$RegulatoryStandard-$label"
	
	<#$uri = "https://$sddcServer/v1/roles"
	$roleConfig = GetSDDCManagerAPIMethod $uri $headers

	$uri = "https://$sddcServer/v1/users"
	$userConfig = GetSDDCManagerAPIMethod $uri $headers

	$roleMap = @{}
	foreach($role in $roleConfig.elements){
		$roleMap[$role.id] = $role.name
	}#>
	if($inputSpecData.$product.$label.DesiredValue -eq "Yes" ){
		$complianceState = $compliant
		$currentValue = "Correct roles are assigned for all the users and groups."
	}
	else{
		$complianceState = $nonCompliant
		$currentValue = "Correct roles are not assigned for all the users and groups."
	}
	
	$noOfSDDCConfigurations++
	

	if($RegulatoryStandard -eq "DISA"){
		$sddcHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
	}
	else{
		$sddcHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
	}
		
	#ControlID = CFAP-4X-000004
	$label = "VI-SDDC-AUD-1603"
	$confLabel = "$RegulatoryStandard-$label"
	
	<#$uri = "https://$sddcServer/v1/domains"
	$domainConfig = GetSDDCManagerAPIMethod $uri $headers
	
	Foreach($domain in $domainConfig.elements){
		$domainName = $domain.name
		$uri = "https://$sddcServer/v1/domains/$domainName/resource-certificates"
		$certificateConfig = GetSDDCManagerAPIMethod $uri $headers
		
	}#>
	if($inputSpecData.$product.$label.DesiredValue -eq "Yes" ){
		$complianceState = $compliant
		$currentValue = "The SSL certificate issuer specified is from an approved certificate authority"
	}
	else{
		$complianceState = $nonCompliant
		$currentValue = "The SSL certificate issuer specified is not from an approved certificate authority"
	}
	$noOfSDDCConfigurations++
	
	if($RegulatoryStandard -eq "DISA"){
		$sddcHashInnerKey[$confLabel] = Set-DISAHash $configData.$product.$label.SRGID $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
	}
	else{
		$sddcHashInnerKey[$confLabel] = Set-Hash $configData.$product.$label.Citation $configData.$product.$label.Description $configData.$product.$label.ParameterName $currentValue $configData.$product.$label.DesiredValue $complianceState
	}
	
	$sddcHashKey[$sddcServer] = $sddcHashInnerKey
	$fileName = $jsonName +"_"+ (Get-Date -Format "dd-MM-yyyy-hh-mm-ss")
	$sddcHashKey | ConvertTo-Json | Out-File "$ReportPath\$fileName.json"
	Generate-Report $sddcHashKey $jsonName $RegulatoryStandard $ReportPath
	<#Write-Verbose ""
	if($auditAllFlag -eq 0){
		Write-Output "Audit of $noOfSDDCConfigurations Configurations of SDDC Manager is done and report can be found at : $ReportPath\$fileName.json and $ReportPath\$fileName.xlsx"
	}#>
	
	$sddcAuditDetails["jsonReportName"] = $fileName+".json"
	$sddcAuditDetails["excelReportName"] = $fileName+".xlsx"
	$sddcAuditDetails["reportPath"] = $ReportPath
	$sddcAuditDetails["noOfSddcConfigurationsAudited"] = $noOfSDDCConfigurations
		
		
	return $sddcAuditDetails
}